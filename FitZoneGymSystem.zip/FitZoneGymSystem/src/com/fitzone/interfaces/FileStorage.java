package com.fitzone.interfaces;

import java.util.List;

public interface FileStorage<T> {
    void saveData(List<T> data) throws Exception;
    List<T> loadData() throws Exception;
    void updateData(T item) throws Exception;
    void deleteData(String id) throws Exception;
}