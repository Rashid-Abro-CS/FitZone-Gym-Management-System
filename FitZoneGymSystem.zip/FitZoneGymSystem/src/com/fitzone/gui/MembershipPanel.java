package com.fitzone.gui;

import com.fitzone.model.MembershipPlan;
import com.fitzone.service.MembershipPlanService;
import com.fitzone.util.ImageUtils;
import com.fitzone.util.ValidationUtils;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Membership Plans Management Panel - FitZone Gym Management System
 * Allows CRUD operations on membership plans with a professional UI.
 */
public class MembershipPanel extends JPanel {

    private MembershipPlanService planService;

    // Table components
    private JTable planTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JButton searchBtn, refreshBtn, addBtn, editBtn, deleteBtn, clearBtn;

    // Form fields
    private JTextField planIdField;
    private JTextField planNameField;
    private JTextField durationField;
    private JTextField feeField;
    private JTextArea descriptionArea;
    private JComboBox<String> statusCombo;

    // For editing
    private MembershipPlan currentEditingPlan = null;

    public MembershipPanel() {
        planService = new MembershipPlanService();

        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(45, 45, 45));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // ---- Top: Title and search ----
        JPanel topPanel = new JPanel(new BorderLayout(10, 5));
        topPanel.setOpaque(false);

        JLabel titleLabel = new JLabel("MEMBERSHIP PLANS", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        topPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setOpaque(false);
        searchPanel.add(new JLabel("Search:"));
        searchField = new JTextField(20);
        searchPanel.add(searchField);
        searchBtn = new JButton("Search");
        searchBtn.setBackground(new Color(70, 130, 180));
        searchBtn.setForeground(Color.WHITE);
        searchBtn.setFocusPainted(false);
        refreshBtn = new JButton("Refresh");
        refreshBtn.setBackground(new Color(100, 100, 100));
        refreshBtn.setForeground(Color.WHITE);
        refreshBtn.setFocusPainted(false);
        searchPanel.add(searchBtn);
        searchPanel.add(refreshBtn);

        topPanel.add(searchPanel, BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        // ---- Center: Table ----
        String[] columns = {"Plan ID", "Plan Name", "Duration (Months)", "Fee (Rs.)", "Status", "Description"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        planTable = new JTable(tableModel);
        planTable.setRowHeight(25);
        planTable.getTableHeader().setBackground(new Color(60, 60, 60));
        planTable.getTableHeader().setForeground(Color.WHITE);
        planTable.setBackground(new Color(50, 50, 50));
        planTable.setForeground(Color.WHITE);
        planTable.setSelectionBackground(new Color(200, 50, 50));
        planTable.setSelectionForeground(Color.WHITE);
        planTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        planTable.setFont(new Font("Arial", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(planTable);
        scrollPane.getViewport().setBackground(new Color(45, 45, 45));
        add(scrollPane, BorderLayout.CENTER);

        // ---- Bottom: Form and buttons ----
        JPanel bottomPanel = new JPanel(new BorderLayout(10, 10));
        bottomPanel.setOpaque(false);

        // Form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 1),
                "Plan Details",
                TitledBorder.CENTER,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                Color.WHITE
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Plan ID (auto-generated, read-only)
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Plan ID:"), gbc);
        gbc.gridx = 1;
        planIdField = new JTextField(15);
        planIdField.setEditable(false);
        planIdField.setBackground(new Color(60, 60, 60));
        planIdField.setForeground(Color.WHITE);
        formPanel.add(planIdField, gbc);

        // Plan Name
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Plan Name:"), gbc);
        gbc.gridx = 1;
        planNameField = new JTextField(15);
        formPanel.add(planNameField, gbc);

        // Duration
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Duration (Months):"), gbc);
        gbc.gridx = 1;
        durationField = new JTextField(15);
        formPanel.add(durationField, gbc);

        // Fee
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(new JLabel("Fee (Rs.):"), gbc);
        gbc.gridx = 1;
        feeField = new JTextField(15);
        formPanel.add(feeField, gbc);

        // Status
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(new JLabel("Status:"), gbc);
        gbc.gridx = 1;
        statusCombo = new JComboBox<>(new String[]{"Active", "Inactive"});
        formPanel.add(statusCombo, gbc);

        // Description
        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(new JLabel("Description:"), gbc);
        gbc.gridx = 1;
        descriptionArea = new JTextArea(3, 15);
        descriptionArea.setLineWrap(true);
        descriptionArea.setWrapStyleWord(true);
        JScrollPane descScroll = new JScrollPane(descriptionArea);
        descScroll.setPreferredSize(new Dimension(150, 60));
        formPanel.add(descScroll, gbc);

        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        buttonPanel.setOpaque(false);

        addBtn = new JButton("Add");
        addBtn.setBackground(new Color(0, 150, 0));
        addBtn.setForeground(Color.WHITE);
        addBtn.setFocusPainted(false);
        addBtn.setIcon(ImageUtils.loadImage("resources/membership.png", 20, 20));

        editBtn = new JButton("Edit");
        editBtn.setBackground(new Color(200, 160, 0));
        editBtn.setForeground(Color.WHITE);
        editBtn.setFocusPainted(false);

        deleteBtn = new JButton("Delete");
        deleteBtn.setBackground(new Color(200, 50, 50));
        deleteBtn.setForeground(Color.WHITE);
        deleteBtn.setFocusPainted(false);

        clearBtn = new JButton("Clear");
        clearBtn.setBackground(new Color(100, 100, 100));
        clearBtn.setForeground(Color.WHITE);
        clearBtn.setFocusPainted(false);

        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(clearBtn);

        // Add form and buttons to bottom panel
        bottomPanel.add(formPanel, BorderLayout.CENTER);
        bottomPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(bottomPanel, BorderLayout.SOUTH);

        // ---- Load data ----
        loadPlanData();

        // ---- Event Listeners ----
        addBtn.addActionListener(e -> addPlan());
        editBtn.addActionListener(e -> editPlan());
        deleteBtn.addActionListener(e -> deletePlan());
        clearBtn.addActionListener(e -> clearForm());
        searchBtn.addActionListener(e -> searchPlan());
        refreshBtn.addActionListener(e -> {
            loadPlanData();
            clearForm();
        });

        // Table selection listener to populate form for editing
        planTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = planTable.getSelectedRow();
                if (row >= 0) {
                    String planId = (String) tableModel.getValueAt(row, 0);
                    MembershipPlan plan = planService.getAllPlans().stream()
                            .filter(p -> p.getPlanId().equals(planId))
                            .findFirst().orElse(null);
                    if (plan != null) {
                        populateForm(plan);
                    }
                }
            }
        });
    }

    /**
     * Load all membership plans into the table
     */
    private void loadPlanData() {
        tableModel.setRowCount(0);
        List<MembershipPlan> plans = planService.getAllPlans();
        for (MembershipPlan p : plans) {
            tableModel.addRow(new Object[]{
                    p.getPlanId(),
                    p.getPlanName(),
                    p.getDurationMonths(),
                    p.getFee(),
                    p.getStatus(),
                    p.getDescription()
            });
        }
    }

    /**
     * Search plans by keyword (ID, Name)
     */
    private void searchPlan() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) {
            loadPlanData();
            return;
        }
        tableModel.setRowCount(0);
        List<MembershipPlan> filtered = planService.searchPlans(keyword);
        for (MembershipPlan p : filtered) {
            tableModel.addRow(new Object[]{
                    p.getPlanId(),
                    p.getPlanName(),
                    p.getDurationMonths(),
                    p.getFee(),
                    p.getStatus(),
                    p.getDescription()
            });
        }
    }

    /**
     * Generate next Plan ID (PLN + timestamp)
     */
    private String generatePlanId() {
        return "PLN" + System.currentTimeMillis();
    }

    /**
     * Clear form and reset editing state
     */
    private void clearForm() {
        planIdField.setText("");
        planNameField.setText("");
        durationField.setText("");
        feeField.setText("");
        descriptionArea.setText("");
        statusCombo.setSelectedIndex(0);
        currentEditingPlan = null;
        planTable.clearSelection();
        addBtn.setText("Add");
    }

    /**
     * Populate form with data from a MembershipPlan object
     */
    private void populateForm(MembershipPlan plan) {
        planIdField.setText(plan.getPlanId());
        planNameField.setText(plan.getPlanName());
        durationField.setText(String.valueOf(plan.getDurationMonths()));
        feeField.setText(String.valueOf(plan.getFee()));
        descriptionArea.setText(plan.getDescription());
        statusCombo.setSelectedItem(plan.getStatus());
        currentEditingPlan = plan;
        addBtn.setText("Update");
    }

    /**
     * Validate form fields
     */
    private boolean validateForm() {
        if (planNameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Plan Name is required.");
            return false;
        }
        if (!ValidationUtils.isInteger(durationField.getText().trim()) ||
                Integer.parseInt(durationField.getText().trim()) <= 0) {
            JOptionPane.showMessageDialog(this, "Duration must be a positive integer.");
            return false;
        }
        if (!ValidationUtils.isPositiveNumber(feeField.getText().trim())) {
            JOptionPane.showMessageDialog(this, "Fee must be a positive number.");
            return false;
        }
        return true;
    }

    /**
     * Add new membership plan
     */
    private void addPlan() {
        if (!validateForm()) return;

        MembershipPlan plan = new MembershipPlan();
        plan.setPlanId(generatePlanId());
        plan.setPlanName(planNameField.getText().trim());
        plan.setDurationMonths(Integer.parseInt(durationField.getText().trim()));
        plan.setFee(Double.parseDouble(feeField.getText().trim()));
        plan.setDescription(descriptionArea.getText().trim());
        plan.setStatus((String) statusCombo.getSelectedItem());

        planService.addPlan(plan);
        JOptionPane.showMessageDialog(this, "Membership plan added successfully.");
        loadPlanData();
        clearForm();
    }

    /**
     * Edit existing membership plan
     */
    private void editPlan() {
        if (currentEditingPlan == null) {
            JOptionPane.showMessageDialog(this, "Please select a plan from the table to edit.");
            return;
        }
        if (!validateForm()) return;

        currentEditingPlan.setPlanName(planNameField.getText().trim());
        currentEditingPlan.setDurationMonths(Integer.parseInt(durationField.getText().trim()));
        currentEditingPlan.setFee(Double.parseDouble(feeField.getText().trim()));
        currentEditingPlan.setDescription(descriptionArea.getText().trim());
        currentEditingPlan.setStatus((String) statusCombo.getSelectedItem());

        planService.updatePlan(currentEditingPlan);
        JOptionPane.showMessageDialog(this, "Membership plan updated successfully.");
        loadPlanData();
        clearForm();
    }

    /**
     * Delete selected membership plan
     */
    private void deletePlan() {
        int row = planTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a plan to delete.");
            return;
        }
        String planId = (String) tableModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete plan " + planId + "?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            planService.deletePlan(planId);
            JOptionPane.showMessageDialog(this, "Plan deleted.");
            loadPlanData();
            clearForm();
        }
    }
}