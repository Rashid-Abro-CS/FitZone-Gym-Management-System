package com.fitzone.model;

import java.io.Serializable;
import java.time.LocalDate;

public class Payment implements Serializable {
    private static final long serialVersionUID = 1L;

    private String paymentId;
    private String memberId;
    private String memberName;
    private String membershipPlan; // Plan name
    private double amount;
    private LocalDate paymentDate;
    private String paymentMethod; // Cash, Bank Transfer, EasyPaisa, JazzCash, Card
    private double dueAmount; // If partial
    private String status; // Paid, Partial, Pending

    public Payment() {}

    public Payment(String paymentId, String memberId, String memberName, String membershipPlan,
                   double amount, LocalDate paymentDate, String paymentMethod,
                   double dueAmount, String status) {
        this.paymentId = paymentId;
        this.memberId = memberId;
        this.memberName = memberName;
        this.membershipPlan = membershipPlan;
        this.amount = amount;
        this.paymentDate = paymentDate;
        this.paymentMethod = paymentMethod;
        this.dueAmount = dueAmount;
        this.status = status;
    }

    // Getters and Setters
    public String getPaymentId() { return paymentId; }
    public void setPaymentId(String paymentId) { this.paymentId = paymentId; }

    public String getMemberId() { return memberId; }
    public void setMemberId(String memberId) { this.memberId = memberId; }

    public String getMemberName() { return memberName; }
    public void setMemberName(String memberName) { this.memberName = memberName; }

    public String getMembershipPlan() { return membershipPlan; }
    public void setMembershipPlan(String membershipPlan) { this.membershipPlan = membershipPlan; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public LocalDate getPaymentDate() { return paymentDate; }
    public void setPaymentDate(LocalDate paymentDate) { this.paymentDate = paymentDate; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }

    public double getDueAmount() { return dueAmount; }
    public void setDueAmount(double dueAmount) { this.dueAmount = dueAmount; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}