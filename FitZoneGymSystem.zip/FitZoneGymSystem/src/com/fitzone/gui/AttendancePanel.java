package com.fitzone.gui;

import com.fitzone.model.Attendance;
import com.fitzone.model.Member;
import com.fitzone.service.AttendanceService;
import com.fitzone.service.MemberService;
import com.fitzone.util.DateUtils;
import com.fitzone.util.ImageUtils;
import com.fitzone.util.ValidationUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

public class AttendancePanel extends JPanel {

    private AttendanceService attendanceService;
    private MemberService memberService;

    // UI Components
    private JTable attendanceTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JButton searchBtn, refreshBtn, checkInBtn, checkOutBtn, markAbsentBtn;
    private JComboBox<String> memberCombo; // for selecting member to mark attendance
    private JLabel presentTodayLabel, absentTodayLabel, totalMembersLabel, attendancePercentLabel;

    // Statistics panel
    private JPanel statsPanel;

    public AttendancePanel() {
        attendanceService = new AttendanceService();
        memberService = new MemberService();

        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(45, 45, 45));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // --- Top: Statistics Cards ---
        statsPanel = createStatsPanel();
        add(statsPanel, BorderLayout.NORTH);

        // --- Center: Table with search ---
        JPanel centerPanel = new JPanel(new BorderLayout(5, 5));
        centerPanel.setOpaque(false);

        // Search bar
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setOpaque(false);
        searchPanel.add(new JLabel("Search:"));
        searchField = new JTextField(20);
        searchPanel.add(searchField);
        searchBtn = new JButton("Search");
        searchBtn.setBackground(new Color(70, 130, 180));
        searchBtn.setForeground(Color.WHITE);
        searchBtn.setFocusPainted(false);
        refreshBtn = new JButton("Refresh");
        refreshBtn.setBackground(new Color(100, 100, 100));
        refreshBtn.setForeground(Color.WHITE);
        refreshBtn.setFocusPainted(false);
        searchPanel.add(searchBtn);
        searchPanel.add(refreshBtn);

        centerPanel.add(searchPanel, BorderLayout.NORTH);

        // Table
        String[] columns = {"Attendance ID", "Member ID", "Member Name", "Date", "Check-In", "Check-Out", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        attendanceTable = new JTable(tableModel);
        attendanceTable.setRowHeight(25);
        attendanceTable.getTableHeader().setBackground(new Color(60, 60, 60));
        attendanceTable.getTableHeader().setForeground(Color.WHITE);
        attendanceTable.setBackground(new Color(50, 50, 50));
        attendanceTable.setForeground(Color.WHITE);
        attendanceTable.setSelectionBackground(new Color(200, 50, 50));
        attendanceTable.setSelectionForeground(Color.WHITE);
        attendanceTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        attendanceTable.setFont(new Font("Arial", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(attendanceTable);
        scrollPane.getViewport().setBackground(new Color(45, 45, 45));
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        add(centerPanel, BorderLayout.CENTER);

        // --- Bottom: Action buttons and member selection ---
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        bottomPanel.setOpaque(false);

        // Member selection for check-in/out
        bottomPanel.add(new JLabel("Select Member:"));
        memberCombo = new JComboBox<>();
        populateMemberCombo();
        memberCombo.setPreferredSize(new Dimension(180, 30));
        bottomPanel.add(memberCombo);

        checkInBtn = new JButton("CHECK IN");
        checkInBtn.setBackground(new Color(0, 150, 0));
        checkInBtn.setForeground(Color.WHITE);
        checkInBtn.setFocusPainted(false);
        checkInBtn.setIcon(ImageUtils.loadImage("resources/attendance.png", 20, 20));

        checkOutBtn = new JButton("CHECK OUT");
        checkOutBtn.setBackground(new Color(200, 150, 0));
        checkOutBtn.setForeground(Color.WHITE);
        checkOutBtn.setFocusPainted(false);

        markAbsentBtn = new JButton("MARK ABSENT");
        markAbsentBtn.setBackground(new Color(200, 50, 50));
        markAbsentBtn.setForeground(Color.WHITE);
        markAbsentBtn.setFocusPainted(false);

        bottomPanel.add(checkInBtn);
        bottomPanel.add(checkOutBtn);
        bottomPanel.add(markAbsentBtn);

        add(bottomPanel, BorderLayout.SOUTH);

        // Load initial data
        loadAttendanceData();
        updateStatistics();

        // --- Event Listeners ---
        searchBtn.addActionListener(e -> searchAttendance());
        refreshBtn.addActionListener(e -> {
            loadAttendanceData();
            updateStatistics();
            populateMemberCombo();
        });
        checkInBtn.addActionListener(e -> markCheckIn());
        checkOutBtn.addActionListener(e -> markCheckOut());
        markAbsentBtn.addActionListener(e -> markAbsent());
    }

    /**
     * Creates the statistics panel with colorful cards.
     */
    private JPanel createStatsPanel() {
        // Builds the statistics cards panel (Present/Absent/Total/Percentage)
        // using the working helper method below.
        return createStatsPanelWithLabels();
    }

    private JPanel createStatsPanelWithLabels() {
        JPanel panel = new JPanel(new GridLayout(1, 4, 15, 10));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

        // Initialize labels
        presentTodayLabel = new JLabel("0", SwingConstants.CENTER);
        absentTodayLabel = new JLabel("0", SwingConstants.CENTER);
        totalMembersLabel = new JLabel("0", SwingConstants.CENTER);
        attendancePercentLabel = new JLabel("0%", SwingConstants.CENTER);

        panel.add(createCard("Present Today", presentTodayLabel, new Color(0, 120, 200)));
        panel.add(createCard("Absent Today", absentTodayLabel, new Color(200, 50, 50)));
        panel.add(createCard("Total Members", totalMembersLabel, new Color(0, 160, 80)));
        panel.add(createCard("Attendance %", attendancePercentLabel, new Color(200, 160, 0)));

        return panel;
    }

    private JPanel createCard(String title, JLabel valueLabel, Color bgColor) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(bgColor);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.WHITE, 1),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        card.setPreferredSize(new Dimension(150, 80));

        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        titleLabel.setForeground(Color.WHITE);
        card.add(titleLabel, BorderLayout.NORTH);

        valueLabel.setFont(new Font("Arial", Font.BOLD, 22));
        valueLabel.setForeground(Color.WHITE);
        card.add(valueLabel, BorderLayout.CENTER);

        return card;
    }

    /**
     * Populate member combo with all active members.
     */
    private void populateMemberCombo() {
        memberCombo.removeAllItems();
        List<Member> members = memberService.getAllMembers();
        // Optionally filter only active
        for (Member m : members) {
            memberCombo.addItem(m.getId() + " - " + m.getFullName());
        }
        if (members.isEmpty()) {
            memberCombo.addItem("No members");
        }
    }

    /**
     * Load all attendance records into the table.
     */
    private void loadAttendanceData() {
        tableModel.setRowCount(0);
        List<Attendance> list = attendanceService.getAllAttendances();
        for (Attendance a : list) {
            tableModel.addRow(new Object[]{
                a.getAttendanceId(),
                a.getMemberId(),
                a.getMemberName(),
                DateUtils.formatDate(a.getDate()),
                a.getCheckInTime() != null ? a.getCheckInTime().format(DateTimeFormatter.ofPattern("HH:mm")) : "",
                a.getCheckOutTime() != null ? a.getCheckOutTime().format(DateTimeFormatter.ofPattern("HH:mm")) : "",
                a.getStatus()
            });
        }
    }

    /**
     * Search attendance by keyword (ID, name).
     */
    private void searchAttendance() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) {
            loadAttendanceData();
            return;
        }
        tableModel.setRowCount(0);
        List<Attendance> all = attendanceService.getAllAttendances();
        List<Attendance> filtered = all.stream()
                .filter(a -> a.getAttendanceId().toLowerCase().contains(keyword.toLowerCase()) ||
                             a.getMemberId().toLowerCase().contains(keyword.toLowerCase()) ||
                             a.getMemberName().toLowerCase().contains(keyword.toLowerCase()))
                .collect(Collectors.toList());
        for (Attendance a : filtered) {
            tableModel.addRow(new Object[]{
                a.getAttendanceId(),
                a.getMemberId(),
                a.getMemberName(),
                DateUtils.formatDate(a.getDate()),
                a.getCheckInTime() != null ? a.getCheckInTime().format(DateTimeFormatter.ofPattern("HH:mm")) : "",
                a.getCheckOutTime() != null ? a.getCheckOutTime().format(DateTimeFormatter.ofPattern("HH:mm")) : "",
                a.getStatus()
            });
        }
    }

    /**
     * Update statistics cards.
     */
    private void updateStatistics() {
        long totalMembers = memberService.getTotalMembers();
        long presentToday = attendanceService.getTodayPresent();
        long absentToday = attendanceService.getTodayAbsent();
        // total members expected = all members (or active). We'll use total.
        long expected = totalMembers;
        double percent = expected > 0 ? (presentToday * 100.0 / expected) : 0;

        presentTodayLabel.setText(String.valueOf(presentToday));
        absentTodayLabel.setText(String.valueOf(absentToday));
        totalMembersLabel.setText(String.valueOf(expected));
        attendancePercentLabel.setText(String.format("%.1f%%", percent));
    }

    /**
     * Handle check-in for selected member.
     */
    private void markCheckIn() {
        String selected = (String) memberCombo.getSelectedItem();
        if (selected == null || selected.equals("No members")) {
            JOptionPane.showMessageDialog(this, "Please select a member.");
            return;
        }
        // Extract member ID from combo (format: "ID - Name")
        String memberId = selected.split(" - ")[0];
        Member member = memberService.findMemberById(memberId);
        if (member == null) {
            JOptionPane.showMessageDialog(this, "Member not found.");
            return;
        }

        // Check if already checked in today
        LocalDate today = LocalDate.now();
        List<Attendance> todayList = attendanceService.getTodayAttendance();
        for (Attendance a : todayList) {
            if (a.getMemberId().equals(memberId) && "Present".equals(a.getStatus())) {
                JOptionPane.showMessageDialog(this, "Member already checked in today.");
                return;
            }
        }

        // Generate new attendance ID
        String attId = "ATT" + System.currentTimeMillis();

        Attendance att = new Attendance(
            attId,
            memberId,
            member.getFullName(),
            today,
            LocalTime.now(),
            null,
            "Present"
        );
        attendanceService.addAttendance(att);
        JOptionPane.showMessageDialog(this, "Check-in successful for " + member.getFullName());
        loadAttendanceData();
        updateStatistics();
    }

    /**
     * Handle check-out for selected member.
     */
    private void markCheckOut() {
        String selected = (String) memberCombo.getSelectedItem();
        if (selected == null || selected.equals("No members")) {
            JOptionPane.showMessageDialog(this, "Please select a member.");
            return;
        }
        String memberId = selected.split(" - ")[0];
        Member member = memberService.findMemberById(memberId);
        if (member == null) {
            JOptionPane.showMessageDialog(this, "Member not found.");
            return;
        }

        LocalDate today = LocalDate.now();
        List<Attendance> todayList = attendanceService.getTodayAttendance();
        Attendance found = null;
        for (Attendance a : todayList) {
            if (a.getMemberId().equals(memberId) && "Present".equals(a.getStatus()) && a.getCheckOutTime() == null) {
                found = a;
                break;
            }
        }
        if (found == null) {
            JOptionPane.showMessageDialog(this, "No active check-in found for this member today.");
            return;
        }

        found.setCheckOutTime(LocalTime.now());
        attendanceService.updateAttendance(found);
        JOptionPane.showMessageDialog(this, "Check-out successful for " + member.getFullName());
        loadAttendanceData();
        updateStatistics();
    }

    /**
     * Mark a member as absent for today.
     */
    private void markAbsent() {
        String selected = (String) memberCombo.getSelectedItem();
        if (selected == null || selected.equals("No members")) {
            JOptionPane.showMessageDialog(this, "Please select a member.");
            return;
        }
        String memberId = selected.split(" - ")[0];
        Member member = memberService.findMemberById(memberId);
        if (member == null) {
            JOptionPane.showMessageDialog(this, "Member not found.");
            return;
        }

        // Check if already has an attendance record today
        LocalDate today = LocalDate.now();
        List<Attendance> todayList = attendanceService.getTodayAttendance();
        for (Attendance a : todayList) {
            if (a.getMemberId().equals(memberId)) {
                JOptionPane.showMessageDialog(this, "Attendance already recorded for today.");
                return;
            }
        }

        String attId = "ATT" + System.currentTimeMillis();
        Attendance att = new Attendance(
            attId,
            memberId,
            member.getFullName(),
            today,
            null,
            null,
            "Absent"
        );
        attendanceService.addAttendance(att);
        JOptionPane.showMessageDialog(this, "Marked absent for " + member.getFullName());
        loadAttendanceData();
        updateStatistics();
    }
}