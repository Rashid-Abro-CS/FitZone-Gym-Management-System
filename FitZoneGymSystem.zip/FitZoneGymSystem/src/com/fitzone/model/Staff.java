package com.fitzone.model;

public class Staff extends Person {
    private static final long serialVersionUID = 1L;

    private String role;
    private double salary;

    public Staff() {}

    public Staff(String id, String fullName, String gender, int age, String phone, String email,
                 String address, String role, double salary, String profilePicturePath) {
        super(id, fullName, gender, age, phone, email, address);
        this.role = role;
        this.salary = salary;
        setProfilePicturePath(profilePicturePath);
    }

    // Getters and Setters
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public double getSalary() { return salary; }
    public void setSalary(double salary) { this.salary = salary; }

    @Override
    public String displayInfo() {
        return "Staff ID: " + getId() + "\nName: " + getFullName() + "\nRole: " + role;
    }
}