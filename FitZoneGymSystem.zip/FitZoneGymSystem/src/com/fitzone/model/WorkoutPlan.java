package com.fitzone.model;

import java.io.Serializable;

public class WorkoutPlan implements Serializable {
    private static final long serialVersionUID = 1L;

    private String workoutId;
    private String memberId;
    private String memberName;
    private String trainerName;
    private String workoutType; // e.g., Cardio, Strength
    private String exercise;
    private int sets;
    private int repetitions;
    private double weight; // in kg
    private int durationMinutes;
    private String notes;

    public WorkoutPlan() {}

    public WorkoutPlan(String workoutId, String memberId, String memberName, String trainerName,
                       String workoutType, String exercise, int sets, int repetitions,
                       double weight, int durationMinutes, String notes) {
        this.workoutId = workoutId;
        this.memberId = memberId;
        this.memberName = memberName;
        this.trainerName = trainerName;
        this.workoutType = workoutType;
        this.exercise = exercise;
        this.sets = sets;
        this.repetitions = repetitions;
        this.weight = weight;
        this.durationMinutes = durationMinutes;
        this.notes = notes;
    }

    // Getters and Setters
    public String getWorkoutId() { return workoutId; }
    public void setWorkoutId(String workoutId) { this.workoutId = workoutId; }

    public String getMemberId() { return memberId; }
    public void setMemberId(String memberId) { this.memberId = memberId; }

    public String getMemberName() { return memberName; }
    public void setMemberName(String memberName) { this.memberName = memberName; }

    public String getTrainerName() { return trainerName; }
    public void setTrainerName(String trainerName) { this.trainerName = trainerName; }

    public String getWorkoutType() { return workoutType; }
    public void setWorkoutType(String workoutType) { this.workoutType = workoutType; }

    public String getExercise() { return exercise; }
    public void setExercise(String exercise) { this.exercise = exercise; }

    public int getSets() { return sets; }
    public void setSets(int sets) { this.sets = sets; }

    public int getRepetitions() { return repetitions; }
    public void setRepetitions(int repetitions) { this.repetitions = repetitions; }

    public double getWeight() { return weight; }
    public void setWeight(double weight) { this.weight = weight; }

    public int getDurationMinutes() { return durationMinutes; }
    public void setDurationMinutes(int durationMinutes) { this.durationMinutes = durationMinutes; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}