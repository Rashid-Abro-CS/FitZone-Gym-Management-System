package com.fitzone.service;

import com.fitzone.model.MembershipPlan;
import com.fitzone.util.FileManager;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MembershipPlanService {
    private List<MembershipPlan> plans;
    private final String filePath = "data/membership_plans.dat";

    public MembershipPlanService() {
        plans = FileManager.loadData(filePath);
        if (plans == null) {
            plans = new ArrayList<>();
            loadSampleData();
        }
    }

    private void loadSampleData() {
        // Sample plans will be added by the system on first launch
    }

    public List<MembershipPlan> getAllPlans() {
        return plans;
    }

    public void addPlan(MembershipPlan plan) {
        plans.add(plan);
        FileManager.saveData(plans, filePath);
    }

    public void updatePlan(MembershipPlan plan) {
        for (int i = 0; i < plans.size(); i++) {
            if (plans.get(i).getPlanId().equals(plan.getPlanId())) {
                plans.set(i, plan);
                FileManager.saveData(plans, filePath);
                break;
            }
        }
    }

    public void deletePlan(String planId) {
        plans.removeIf(p -> p.getPlanId().equals(planId));
        FileManager.saveData(plans, filePath);
    }

    public MembershipPlan findPlanById(String planId) {
        return plans.stream().filter(p -> p.getPlanId().equals(planId)).findFirst().orElse(null);
    }

    public List<MembershipPlan> searchPlans(String keyword) {
        String lower = keyword.toLowerCase();
        return plans.stream()
                .filter(p -> p.getPlanId().toLowerCase().contains(lower) ||
                             p.getPlanName().toLowerCase().contains(lower) ||
                             p.getStatus().toLowerCase().contains(lower))
                .collect(Collectors.toList());
    }

    public long getTotalPlans() { return plans.size(); }
    public long getActivePlans() {
        return plans.stream().filter(p -> "Active".equals(p.getStatus())).count();
    }
}
