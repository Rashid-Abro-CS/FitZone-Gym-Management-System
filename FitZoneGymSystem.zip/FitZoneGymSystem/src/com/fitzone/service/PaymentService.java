package com.fitzone.service;

import com.fitzone.model.Payment;
import com.fitzone.util.FileManager;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class PaymentService {
    private List<Payment> payments;
    private final String filePath = "data/payments.dat";

    public PaymentService() {
        payments = FileManager.loadData(filePath);
        if (payments == null) payments = new ArrayList<>();
    }

    public List<Payment> getAllPayments() { return payments; }

    public void addPayment(Payment p) {
        payments.add(p);
        FileManager.saveData(payments, filePath);
    }

    public void updatePayment(Payment p) {
        for (int i = 0; i < payments.size(); i++) {
            if (payments.get(i).getPaymentId().equals(p.getPaymentId())) {
                payments.set(i, p);
                FileManager.saveData(payments, filePath);
                break;
            }
        }
    }

    public void deletePayment(String id) {
        payments.removeIf(p -> p.getPaymentId().equals(id));
        FileManager.saveData(payments, filePath);
    }

    public List<Payment> searchPayments(String keyword) {
        String lower = keyword.toLowerCase();
        return payments.stream()
                .filter(p -> p.getPaymentId().toLowerCase().contains(lower) ||
                             p.getMemberId().toLowerCase().contains(lower) ||
                             p.getMemberName().toLowerCase().contains(lower))
                .collect(Collectors.toList());
    }

    public double getMonthlyRevenue() {
        // Sum payments of current month
        java.time.LocalDate now = java.time.LocalDate.now();
        return payments.stream()
                .filter(p -> p.getPaymentDate().getMonth() == now.getMonth() &&
                             p.getPaymentDate().getYear() == now.getYear() &&
                             "Paid".equals(p.getStatus()))
                .mapToDouble(Payment::getAmount).sum();
    }
}