package com.fitzone.interfaces;

public interface Payable {
    double calculateAmount();
    void processPayment();
}