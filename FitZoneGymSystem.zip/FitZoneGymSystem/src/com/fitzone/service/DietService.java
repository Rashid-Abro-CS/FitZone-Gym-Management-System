package com.fitzone.service;

import com.fitzone.model.DietPlan;
import com.fitzone.util.FileManager;
import java.util.ArrayList;
import java.util.List;

public class DietService {
    private List<DietPlan> diets;
    private final String filePath = "data/diet_plans.dat";

    public DietService() {
        diets = FileManager.loadData(filePath);
        if (diets == null) diets = new ArrayList<>();
    }

    public List<DietPlan> getAllDiets() { return diets; }

    public void addDiet(DietPlan d) {
        diets.add(d);
        FileManager.saveData(diets, filePath);
    }

    public void updateDiet(DietPlan d) {
        for (int i = 0; i < diets.size(); i++) {
            if (diets.get(i).getDietId().equals(d.getDietId())) {
                diets.set(i, d);
                FileManager.saveData(diets, filePath);
                break;
            }
        }
    }

    public void deleteDiet(String id) {
        diets.removeIf(d -> d.getDietId().equals(id));
        FileManager.saveData(diets, filePath);
    }

    public List<DietPlan> getDietsForMember(String memberId) {
        List<DietPlan> result = new ArrayList<>();
        for (DietPlan d : diets) {
            if (d.getMemberId().equals(memberId)) result.add(d);
        }
        return result;
    }
}