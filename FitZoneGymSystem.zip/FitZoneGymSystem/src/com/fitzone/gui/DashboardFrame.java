package com.fitzone.gui;

import com.fitzone.util.ImageUtils;
import com.fitzone.util.DateUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;

public class DashboardFrame extends JFrame {
    private CardLayout cardLayout;
    private JPanel contentPanel;
    private JLabel timeLabel;

    public DashboardFrame() {
        setTitle("FitZone Gym Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1400, 850);
        setMinimumSize(new Dimension(1100, 700));
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Header
        JPanel header = createHeader();
        add(header, BorderLayout.NORTH);

        // Sidebar and Content
        JPanel mainPanel = new JPanel(new BorderLayout());
        JPanel sidebar = createSidebar();
        mainPanel.add(sidebar, BorderLayout.WEST);

        contentPanel = new JPanel();
        cardLayout = new CardLayout();
        contentPanel.setLayout(cardLayout);
        mainPanel.add(contentPanel, BorderLayout.CENTER);

        add(mainPanel, BorderLayout.CENTER);

        // Add panels to card layout
        contentPanel.add(new JPanel(), "Dashboard"); // placeholder
        contentPanel.add(new MemberPanel(), "Members");
        contentPanel.add(new TrainerPanel(), "Trainers");
        contentPanel.add(new MembershipPanel(), "Membership");
        contentPanel.add(new AttendancePanel(), "Attendance");
        contentPanel.add(new PaymentPanel(), "Payments");
        contentPanel.add(new WorkoutPanel(), "Workouts");
        contentPanel.add(new DietPanel(), "Diets");
        contentPanel.add(new ReportPanel(), "Reports");
        contentPanel.add(new BMIPanel(), "BMI");
        contentPanel.add(new NotificationPanel(), "Notifications");
        contentPanel.add(new SettingsPanel(), "Settings");

        // Show Dashboard by default
        cardLayout.show(contentPanel, "Dashboard");

        // Update time
        Timer timer = new Timer(1000, e -> {
            timeLabel.setText(DateUtils.getCurrentTime());
        });
        timer.start();
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(30, 30, 30));
        header.setPreferredSize(new Dimension(0, 70));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Color.RED));

        JLabel title = new JLabel("FITZONE GYM MANAGEMENT SYSTEM");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setForeground(Color.WHITE);
        title.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
        header.add(title, BorderLayout.WEST);

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        rightPanel.setOpaque(false);

        JLabel adminLabel = new JLabel("Admin");
        adminLabel.setForeground(Color.WHITE);
        adminLabel.setFont(new Font("Arial", Font.PLAIN, 14));

        timeLabel = new JLabel(DateUtils.getCurrentTime());
        timeLabel.setForeground(Color.WHITE);
        timeLabel.setFont(new Font("Arial", Font.PLAIN, 14));

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBackground(new Color(200, 50, 50));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFocusPainted(false);
        logoutBtn.addActionListener(e -> logout());

        rightPanel.add(adminLabel);
        rightPanel.add(timeLabel);
        rightPanel.add(logoutBtn);
        header.add(rightPanel, BorderLayout.EAST);

        return header;
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(40, 40, 40));
        sidebar.setPreferredSize(new Dimension(220, 0));

        String[] items = {
            "Dashboard", "Members", "Trainers", "Membership Plans",
            "Attendance", "Payments", "Workout Plans", "Diet Plans",
            "Reports", "BMI Calculator", "Notifications", "Settings", "Logout"
        };
        String[] icons = {
            "dashboard", "member", "trainer", "membership",
            "attendance", "payment", "workout", "diet",
            "report", "bmi", "notification", "settings", "logout"
        };
        // Card names used when the panels were registered with cardLayout.
        // These must match the "add(panel, cardName)" calls above exactly.
        String[] cardKeys = {
            "Dashboard", "Members", "Trainers", "Membership",
            "Attendance", "Payments", "Workouts", "Diets",
            "Reports", "BMI", "Notifications", "Settings", "Logout"
        };

        for (int i = 0; i < items.length; i++) {
            JButton btn = new JButton(items[i]);
            btn.setAlignmentX(Component.LEFT_ALIGNMENT);
            btn.setMaximumSize(new Dimension(220, 50));
            btn.setMinimumSize(new Dimension(220, 50));
            btn.setPreferredSize(new Dimension(220, 50));
            btn.setBackground(new Color(40, 40, 40));
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setBorder(BorderFactory.createEmptyBorder(5, 20, 5, 5));
            btn.setFont(new Font("Arial", Font.PLAIN, 14));
            btn.setHorizontalAlignment(SwingConstants.LEFT);

            // Add icon if exists
            String iconPath = "resources/" + icons[i] + ".png";
            ImageIcon icon = ImageUtils.loadImage(iconPath, 24, 24);
            btn.setIcon(icon);

            // Hover effect
            btn.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    btn.setBackground(new Color(60, 60, 60));
                }
                public void mouseExited(java.awt.event.MouseEvent evt) {
                    btn.setBackground(new Color(40, 40, 40));
                }
            });

            final int index = i;
            btn.addActionListener(e -> {
                if (items[index].equals("Logout")) {
                    logout();
                } else {
                    cardLayout.show(contentPanel, cardKeys[index]);
                }
            });

            sidebar.add(btn);
        }

        return sidebar;
    }

    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            dispose();
            new LoginFrame().setVisible(true);
        }
    }
}