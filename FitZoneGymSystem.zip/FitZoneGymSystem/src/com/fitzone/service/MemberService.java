package com.fitzone.service;

import com.fitzone.model.Member;
import com.fitzone.util.FileManager;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MemberService {
    private List<Member> members;
    private final String filePath = "data/members.dat";

    public MemberService() {
        members = FileManager.loadData(filePath);
        if (members == null) {
            members = new ArrayList<>();
            // Load sample data on first run
            loadSampleData();
        }
    }

    private void loadSampleData() {
        // Sample members will be added by the system on first launch
        // We'll create them in the main initialization later
    }

    public List<Member> getAllMembers() {
        return members;
    }

    public void addMember(Member member) {
        members.add(member);
        FileManager.saveData(members, filePath);
    }

    public void updateMember(Member member) {
        for (int i = 0; i < members.size(); i++) {
            if (members.get(i).getId().equals(member.getId())) {
                members.set(i, member);
                FileManager.saveData(members, filePath);
                break;
            }
        }
    }

    public void deleteMember(String id) {
        members.removeIf(m -> m.getId().equals(id));
        FileManager.saveData(members, filePath);
    }

    public Member findMemberById(String id) {
        return members.stream().filter(m -> m.getId().equals(id)).findFirst().orElse(null);
    }

    public List<Member> searchMembers(String keyword) {
        String lower = keyword.toLowerCase();
        return members.stream()
                .filter(m -> m.getId().toLowerCase().contains(lower) ||
                             m.getFullName().toLowerCase().contains(lower) ||
                             m.getPhone().contains(keyword) ||
                             m.getCnic().contains(keyword))
                .collect(Collectors.toList());
    }

    public long getTotalMembers() { return members.size(); }
    public long getActiveMembers() {
        return members.stream().filter(m -> "Active".equals(m.getStatus())).count();
    }
    public long getExpiredMembers() {
        return members.stream().filter(m -> "Expired".equals(m.getStatus())).count();
    }
    public long getExpiringSoonMembers() {
        return members.stream().filter(m -> "Expiring Soon".equals(m.getStatus())).count();
    }
}