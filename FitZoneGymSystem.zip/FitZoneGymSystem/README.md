# FitZone Gym Management System

**Train Hard. Stay Strong. Live Better.**

A complete desktop application for managing gym operations, built with Java Swing and OOP concepts. No database required—all data stored locally via serialization.

## Features
- Member, Trainer, and Staff Management
- Membership Plans with expiry tracking
- Attendance marking (Check-in/out)
- Payment recording and receipt printing
- Workout and Diet Plans per member
- BMI Calculator
- Reports generation
- Notifications for expiries and pending payments
- Dark/Light theme support
- Professional gym-style UI with images/icons

## Technologies
- Java (JDK 8+)
- Java Swing & AWT
- Java Collections Framework
- File Handling & Object Serialization
- OOP Principles

## Project Structure
- `src/` – all Java source files
- `resources/` – images and icons
- `data/` – serialized data files

## Installation & Running
1. Clone or download the project.
2. Open in IntelliJ IDEA, Eclipse, or NetBeans.
3. Ensure the `resources/` and `data/` folders are in the project root.
4. Compile and run `Main.java`.

## Default Login
- Username: `admin`
- Password: `admin123`

## Data Storage
All data is stored in the `data/` folder as `.dat` files using Java serialization. No internet or external database required.

## Screenshots
(Add screenshots here)

## Future Enhancements
- Cloud backup
- Mobile app integration
- Advanced analytics