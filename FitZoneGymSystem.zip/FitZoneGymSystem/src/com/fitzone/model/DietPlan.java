package com.fitzone.model;

import java.io.Serializable;

public class DietPlan implements Serializable {
    private static final long serialVersionUID = 1L;

    private String dietId;
    private String memberId;
    private String mealType; // Breakfast, Lunch, Dinner, Snack, Pre-Workout, Post-Workout
    private String food;
    private String quantity;
    private int calories;
    private double protein;
    private double carbohydrates;
    private double fats;
    private String notes;

    public DietPlan() {}

    public DietPlan(String dietId, String memberId, String mealType, String food, String quantity,
                    int calories, double protein, double carbohydrates, double fats, String notes) {
        this.dietId = dietId;
        this.memberId = memberId;
        this.mealType = mealType;
        this.food = food;
        this.quantity = quantity;
        this.calories = calories;
        this.protein = protein;
        this.carbohydrates = carbohydrates;
        this.fats = fats;
        this.notes = notes;
    }

    // Getters and Setters
    public String getDietId() { return dietId; }
    public void setDietId(String dietId) { this.dietId = dietId; }

    public String getMemberId() { return memberId; }
    public void setMemberId(String memberId) { this.memberId = memberId; }

    public String getMealType() { return mealType; }
    public void setMealType(String mealType) { this.mealType = mealType; }

    public String getFood() { return food; }
    public void setFood(String food) { this.food = food; }

    public String getQuantity() { return quantity; }
    public void setQuantity(String quantity) { this.quantity = quantity; }

    public int getCalories() { return calories; }
    public void setCalories(int calories) { this.calories = calories; }

    public double getProtein() { return protein; }
    public void setProtein(double protein) { this.protein = protein; }

    public double getCarbohydrates() { return carbohydrates; }
    public void setCarbohydrates(double carbohydrates) { this.carbohydrates = carbohydrates; }

    public double getFats() { return fats; }
    public void setFats(double fats) { this.fats = fats; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}