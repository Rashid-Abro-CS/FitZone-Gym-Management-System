package com.fitzone.gui;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * BMI Calculator Panel - FitZone Gym Management System
 * Provides a professional BMI calculator with visual gauge and category indicators.
 */
public class BMIPanel extends JPanel {

    private JTextField weightField;
    private JTextField heightField;
    private JButton calculateBtn;
    private JButton clearBtn;

    // Result display components
    private JLabel bmiValueLabel;
    private JLabel bmiCategoryLabel;
    private JLabel bmiDescriptionLabel;
    private JPanel gaugePanel; // Visual gauge

    // Color scheme for categories
    private static final Color COLOR_UNDERWEIGHT = new Color(70, 130, 180);  // Steel blue
    private static final Color COLOR_NORMAL = new Color(0, 160, 80);          // Green
    private static final Color COLOR_OVERWEIGHT = new Color(200, 160, 0);     // Gold
    private static final Color COLOR_OBESE = new Color(200, 50, 50);          // Red

    // Category ranges
    private static final double UNDERWEIGHT_MAX = 18.5;
    private static final double NORMAL_MAX = 24.9;
    private static final double OVERWEIGHT_MAX = 29.9;

    public BMIPanel() {
        setLayout(new BorderLayout(15, 15));
        setBackground(new Color(45, 45, 45));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // ---- Title ----
        JLabel titleLabel = new JLabel("BMI CALCULATOR", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        add(titleLabel, BorderLayout.NORTH);

        // ---- Center Panel: Input + Results ----
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Input panel (left side)
        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setOpaque(false);
        inputPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 1),
                "Enter Your Details",
                TitledBorder.CENTER,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 16),
                Color.WHITE
        ));

        GridBagConstraints igbc = new GridBagConstraints();
        igbc.insets = new Insets(8, 8, 8, 8);
        igbc.fill = GridBagConstraints.HORIZONTAL;
        igbc.gridx = 0;
        igbc.gridy = 0;
        inputPanel.add(new JLabel("Weight (kg):"), igbc);
        igbc.gridx = 1;
        weightField = new JTextField(10);
        weightField.setFont(new Font("Arial", Font.PLAIN, 14));
        inputPanel.add(weightField, igbc);

        igbc.gridx = 0;
        igbc.gridy = 1;
        inputPanel.add(new JLabel("Height (cm):"), igbc);
        igbc.gridx = 1;
        heightField = new JTextField(10);
        heightField.setFont(new Font("Arial", Font.PLAIN, 14));
        inputPanel.add(heightField, igbc);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        btnPanel.setOpaque(false);

        calculateBtn = new JButton("CALCULATE BMI");
        calculateBtn.setBackground(new Color(200, 50, 50));
        calculateBtn.setForeground(Color.WHITE);
        calculateBtn.setFocusPainted(false);
        calculateBtn.setFont(new Font("Arial", Font.BOLD, 14));
        calculateBtn.setPreferredSize(new Dimension(150, 40));

        clearBtn = new JButton("CLEAR");
        clearBtn.setBackground(new Color(100, 100, 100));
        clearBtn.setForeground(Color.WHITE);
        clearBtn.setFocusPainted(false);
        clearBtn.setFont(new Font("Arial", Font.BOLD, 14));
        clearBtn.setPreferredSize(new Dimension(100, 40));

        btnPanel.add(calculateBtn);
        btnPanel.add(clearBtn);

        igbc.gridx = 0;
        igbc.gridy = 2;
        igbc.gridwidth = 2;
        inputPanel.add(btnPanel, igbc);

        // Add input panel to center
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.4;
        gbc.fill = GridBagConstraints.BOTH;
        centerPanel.add(inputPanel, gbc);

        // ---- Results Panel (right side) ----
        JPanel resultsPanel = new JPanel(new BorderLayout(10, 10));
        resultsPanel.setOpaque(false);
        resultsPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 1),
                "BMI Result",
                TitledBorder.CENTER,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 16),
                Color.WHITE
        ));

        // BMI value display
        JPanel valuePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        valuePanel.setOpaque(false);
        bmiValueLabel = new JLabel("--");
        bmiValueLabel.setFont(new Font("Arial", Font.BOLD, 48));
        bmiValueLabel.setForeground(Color.WHITE);
        valuePanel.add(bmiValueLabel);
        resultsPanel.add(valuePanel, BorderLayout.NORTH);

        // Gauge (visual indicator)
        gaugePanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                drawGauge(g);
            }
        };
        gaugePanel.setPreferredSize(new Dimension(300, 40));
        gaugePanel.setBackground(new Color(60, 60, 60));
        resultsPanel.add(gaugePanel, BorderLayout.CENTER);

        // Category and description
        JPanel categoryPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        categoryPanel.setOpaque(false);
        bmiCategoryLabel = new JLabel("Category: --", SwingConstants.CENTER);
        bmiCategoryLabel.setFont(new Font("Arial", Font.BOLD, 20));
        bmiCategoryLabel.setForeground(Color.WHITE);
        categoryPanel.add(bmiCategoryLabel);

        bmiDescriptionLabel = new JLabel("", SwingConstants.CENTER);
        bmiDescriptionLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        bmiDescriptionLabel.setForeground(Color.LIGHT_GRAY);
        categoryPanel.add(bmiDescriptionLabel);

        resultsPanel.add(categoryPanel, BorderLayout.SOUTH);

        // Add results panel to center
        gbc.gridx = 1;
        gbc.weightx = 0.6;
        gbc.fill = GridBagConstraints.BOTH;
        centerPanel.add(resultsPanel, gbc);

        add(centerPanel, BorderLayout.CENTER);

        // ---- Footer ----
        JLabel footer = new JLabel("Maintain a healthy BMI for a better life!", SwingConstants.CENTER);
        footer.setFont(new Font("Arial", Font.ITALIC, 14));
        footer.setForeground(Color.LIGHT_GRAY);
        footer.setBorder(BorderFactory.createEmptyBorder(15, 0, 0, 0));
        add(footer, BorderLayout.SOUTH);

        // ---- Event Listeners ----
        calculateBtn.addActionListener(e -> calculateBMI());
        clearBtn.addActionListener(e -> clearFields());

        // Enter key triggers calculation
        weightField.addActionListener(e -> calculateBMI());
        heightField.addActionListener(e -> calculateBMI());
    }

    /**
     * Calculate BMI based on weight (kg) and height (cm).
     */
    private void calculateBMI() {
        String weightStr = weightField.getText().trim();
        String heightStr = heightField.getText().trim();

        if (weightStr.isEmpty() || heightStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both weight and height.", "Missing Input", JOptionPane.WARNING_MESSAGE);
            return;
        }

        double weight, heightCm;
        try {
            weight = Double.parseDouble(weightStr);
            heightCm = Double.parseDouble(heightStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numeric values.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (weight <= 0 || heightCm <= 0) {
            JOptionPane.showMessageDialog(this, "Weight and height must be positive numbers.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Calculate BMI
        double heightM = heightCm / 100.0;
        double bmi = weight / (heightM * heightM);

        // Display result
        bmiValueLabel.setText(String.format("%.1f", bmi));
        updateCategoryAndGauge(bmi);
    }

    /**
     * Update category label, description, and gauge based on BMI value.
     */
    private void updateCategoryAndGauge(double bmi) {
        Color categoryColor;
        String category;
        String description;

        if (bmi < UNDERWEIGHT_MAX) {
            category = "Underweight";
            categoryColor = COLOR_UNDERWEIGHT;
            description = "You may need to gain some weight. Consult a dietitian.";
        } else if (bmi < NORMAL_MAX) {
            category = "Normal Weight";
            categoryColor = COLOR_NORMAL;
            description = "Great! You have a healthy weight. Keep it up!";
        } else if (bmi < OVERWEIGHT_MAX) {
            category = "Overweight";
            categoryColor = COLOR_OVERWEIGHT;
            description = "Consider a balanced diet and regular exercise to reduce weight.";
        } else {
            category = "Obese";
            categoryColor = COLOR_OBESE;
            description = "Please consult a healthcare professional for guidance.";
        }

        bmiCategoryLabel.setText("Category: " + category);
        bmiCategoryLabel.setForeground(categoryColor);
        bmiDescriptionLabel.setText(description);

        // Repaint gauge with new value
        gaugePanel.putClientProperty("bmi", bmi);
        gaugePanel.putClientProperty("categoryColor", categoryColor);
        gaugePanel.repaint();
    }

    /**
     * Draw the BMI gauge with a gradient bar and marker.
     */
    private void drawGauge(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        Dimension size = gaugePanel.getSize();
        int width = size.width - 20;
        int height = size.height - 10;
        int x = 10;
        int y = 5;

        // Background of gauge
        g2d.setColor(new Color(80, 80, 80));
        g2d.fillRoundRect(x, y, width, height, 10, 10);

        // Draw gradient bar: underweight -> normal -> overweight -> obese
        // We'll divide the bar into four segments with corresponding colors
        int segmentWidth = width / 4;
        Color[] colors = {COLOR_UNDERWEIGHT, COLOR_NORMAL, COLOR_OVERWEIGHT, COLOR_OBESE};
        for (int i = 0; i < 4; i++) {
            g2d.setColor(colors[i]);
            g2d.fillRect(x + i * segmentWidth, y + 2, segmentWidth, height - 4);
        }

        // Draw tick marks for category boundaries
        g2d.setColor(Color.WHITE);
        for (int i = 1; i < 4; i++) {
            int tickX = x + i * segmentWidth;
            g2d.drawLine(tickX, y, tickX, y + height);
        }

        // Get BMI value from client property, default to -1 if not set
        Double bmi = (Double) gaugePanel.getClientProperty("bmi");
        if (bmi != null && bmi >= 0) {
            // Map BMI to position: BMI ranges 10 to 40, clamp between 10 and 40
            double clamped = Math.min(40, Math.max(10, bmi));
            double position = (clamped - 10) / 30.0; // 0 to 1
            int markerX = x + (int) (position * width);

            // Draw marker (triangle pointing down)
            int[] xPoints = {markerX, markerX - 8, markerX + 8};
            int[] yPoints = {y - 2, y + 12, y + 12};
            g2d.setColor(Color.WHITE);
            g2d.fillPolygon(xPoints, yPoints, 3);
            g2d.setColor(Color.BLACK);
            g2d.drawPolygon(xPoints, yPoints, 3);

            // Draw value above marker
            g2d.setColor(Color.WHITE);
            g2d.setFont(new Font("Arial", Font.BOLD, 10));
            String valStr = String.format("%.1f", bmi);
            int valWidth = g2d.getFontMetrics().stringWidth(valStr);
            g2d.drawString(valStr, markerX - valWidth / 2, y - 8);
        }

        // Labels for categories (small text under bar)
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.PLAIN, 9));
        String[] labels = {"Under", "Normal", "Over", "Obese"};
        for (int i = 0; i < 4; i++) {
            int labelX = x + i * segmentWidth + segmentWidth / 2;
            int labelWidth = g2d.getFontMetrics().stringWidth(labels[i]);
            g2d.drawString(labels[i], labelX - labelWidth / 2, y + height + 15);
        }
    }

    /**
     * Clear all input fields and reset results.
     */
    private void clearFields() {
        weightField.setText("");
        heightField.setText("");
        bmiValueLabel.setText("--");
        bmiCategoryLabel.setText("Category: --");
        bmiCategoryLabel.setForeground(Color.WHITE);
        bmiDescriptionLabel.setText("");
        gaugePanel.putClientProperty("bmi", null);
        gaugePanel.repaint();
        weightField.requestFocus();
    }
}