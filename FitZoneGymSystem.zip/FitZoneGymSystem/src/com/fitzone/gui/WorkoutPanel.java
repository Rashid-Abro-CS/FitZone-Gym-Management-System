package com.fitzone.gui;

import com.fitzone.model.WorkoutPlan;
import com.fitzone.model.Member;
import com.fitzone.model.Trainer;
import com.fitzone.service.WorkoutService;
import com.fitzone.service.MemberService;
import com.fitzone.service.TrainerService;
import com.fitzone.util.ImageUtils;
import com.fitzone.util.ValidationUtils;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.stream.Collectors;

public class WorkoutPanel extends JPanel {

    private WorkoutService workoutService;
    private MemberService memberService;
    private TrainerService trainerService;

    // Table components
    private JTable workoutTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JButton searchBtn, refreshBtn, addBtn, editBtn, deleteBtn, clearBtn, printBtn;

    // Form fields
    private JTextField workoutIdField;
    private JComboBox<String> memberCombo;
    private JComboBox<String> trainerCombo;
    private JComboBox<String> workoutTypeCombo;
    private JComboBox<String> exerciseCombo;
    private JSpinner setsSpinner;
    private JSpinner repsSpinner;
    private JTextField weightField;
    private JSpinner durationSpinner;
    private JTextArea notesArea;

    // For editing
    private WorkoutPlan currentEditingWorkout = null;

    public WorkoutPanel() {
        workoutService = new WorkoutService();
        memberService = new MemberService();
        trainerService = new TrainerService();

        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(45, 45, 45));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // ---- Top: Title and search ----
        JPanel topPanel = new JPanel(new BorderLayout(10, 5));
        topPanel.setOpaque(false);

        JLabel titleLabel = new JLabel("WORKOUT PLANS", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        topPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setOpaque(false);
        searchPanel.add(new JLabel("Search:"));
        searchField = new JTextField(20);
        searchPanel.add(searchField);
        searchBtn = new JButton("Search");
        searchBtn.setBackground(new Color(70, 130, 180));
        searchBtn.setForeground(Color.WHITE);
        searchBtn.setFocusPainted(false);
        refreshBtn = new JButton("Refresh");
        refreshBtn.setBackground(new Color(100, 100, 100));
        refreshBtn.setForeground(Color.WHITE);
        refreshBtn.setFocusPainted(false);
        searchPanel.add(searchBtn);
        searchPanel.add(refreshBtn);

        topPanel.add(searchPanel, BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        // ---- Center: Table ----
        String[] columns = {"Workout ID", "Member", "Trainer", "Type", "Exercise", "Sets", "Reps", "Weight (kg)"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        workoutTable = new JTable(tableModel);
        workoutTable.setRowHeight(25);
        workoutTable.getTableHeader().setBackground(new Color(60, 60, 60));
        workoutTable.getTableHeader().setForeground(Color.WHITE);
        workoutTable.setBackground(new Color(50, 50, 50));
        workoutTable.setForeground(Color.WHITE);
        workoutTable.setSelectionBackground(new Color(200, 50, 50));
        workoutTable.setSelectionForeground(Color.WHITE);
        workoutTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        workoutTable.setFont(new Font("Arial", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(workoutTable);
        scrollPane.getViewport().setBackground(new Color(45, 45, 45));
        add(scrollPane, BorderLayout.CENTER);

        // ---- Bottom: Form and buttons ----
        JPanel bottomPanel = new JPanel(new BorderLayout(10, 10));
        bottomPanel.setOpaque(false);

        // Form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 1),
                "Workout Details",
                TitledBorder.CENTER,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                Color.WHITE
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Row 0: Workout ID (auto-generated)
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Workout ID:"), gbc);
        gbc.gridx = 1;
        workoutIdField = new JTextField(15);
        workoutIdField.setEditable(false);
        workoutIdField.setBackground(new Color(60, 60, 60));
        workoutIdField.setForeground(Color.WHITE);
        formPanel.add(workoutIdField, gbc);

        // Row 1: Member
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Member:"), gbc);
        gbc.gridx = 1;
        memberCombo = new JComboBox<>();
        memberCombo.setPreferredSize(new Dimension(150, 25));
        populateMemberCombo();
        formPanel.add(memberCombo, gbc);

        // Row 2: Trainer
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Trainer:"), gbc);
        gbc.gridx = 1;
        trainerCombo = new JComboBox<>();
        populateTrainerCombo();
        formPanel.add(trainerCombo, gbc);

        // Row 3: Workout Type
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(new JLabel("Workout Type:"), gbc);
        gbc.gridx = 1;
        workoutTypeCombo = new JComboBox<>(new String[]{"Strength", "Cardio", "Flexibility", "HIIT", "Endurance"});
        formPanel.add(workoutTypeCombo, gbc);

        // Row 4: Exercise
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(new JLabel("Exercise:"), gbc);
        gbc.gridx = 1;
        exerciseCombo = new JComboBox<>(new String[]{
                "Bench Press", "Squats", "Deadlift", "Push Ups", "Pull Ups",
                "Shoulder Press", "Bicep Curl", "Tricep Extension", "Running",
                "Cycling", "Leg Press", "Lat Pulldown", "Plank", "Lunges"
        });
        formPanel.add(exerciseCombo, gbc);

        // Row 5: Sets and Reps
        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(new JLabel("Sets:"), gbc);
        gbc.gridx = 1;
        setsSpinner = new JSpinner(new SpinnerNumberModel(3, 1, 10, 1));
        formPanel.add(setsSpinner, gbc);

        gbc.gridx = 2;
        gbc.gridy = 5;
        formPanel.add(new JLabel("Reps:"), gbc);
        gbc.gridx = 3;
        repsSpinner = new JSpinner(new SpinnerNumberModel(10, 1, 50, 1));
        formPanel.add(repsSpinner, gbc);

        // Row 6: Weight and Duration
        gbc.gridx = 0;
        gbc.gridy = 6;
        formPanel.add(new JLabel("Weight (kg):"), gbc);
        gbc.gridx = 1;
        weightField = new JTextField(15);
        formPanel.add(weightField, gbc);

        gbc.gridx = 2;
        gbc.gridy = 6;
        formPanel.add(new JLabel("Duration (min):"), gbc);
        gbc.gridx = 3;
        durationSpinner = new JSpinner(new SpinnerNumberModel(30, 5, 180, 5));
        formPanel.add(durationSpinner, gbc);

        // Row 7: Notes
        gbc.gridx = 0;
        gbc.gridy = 7;
        formPanel.add(new JLabel("Notes:"), gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 3;
        notesArea = new JTextArea(2, 20);
        notesArea.setLineWrap(true);
        notesArea.setWrapStyleWord(true);
        JScrollPane notesScroll = new JScrollPane(notesArea);
        notesScroll.setPreferredSize(new Dimension(250, 40));
        formPanel.add(notesScroll, gbc);
        gbc.gridwidth = 1;

        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        buttonPanel.setOpaque(false);

        addBtn = new JButton("Add");
        addBtn.setBackground(new Color(0, 150, 0));
        addBtn.setForeground(Color.WHITE);
        addBtn.setFocusPainted(false);
        addBtn.setIcon(ImageUtils.loadImage("resources/workout.png", 20, 20));

        editBtn = new JButton("Edit");
        editBtn.setBackground(new Color(200, 160, 0));
        editBtn.setForeground(Color.WHITE);
        editBtn.setFocusPainted(false);

        deleteBtn = new JButton("Delete");
        deleteBtn.setBackground(new Color(200, 50, 50));
        deleteBtn.setForeground(Color.WHITE);
        deleteBtn.setFocusPainted(false);

        clearBtn = new JButton("Clear");
        clearBtn.setBackground(new Color(100, 100, 100));
        clearBtn.setForeground(Color.WHITE);
        clearBtn.setFocusPainted(false);

        printBtn = new JButton("Print");
        printBtn.setBackground(new Color(70, 130, 180));
        printBtn.setForeground(Color.WHITE);
        printBtn.setFocusPainted(false);

        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(clearBtn);
        buttonPanel.add(printBtn);

        // Add form and buttons to bottom panel
        bottomPanel.add(formPanel, BorderLayout.CENTER);
        bottomPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(bottomPanel, BorderLayout.SOUTH);

        // ---- Load data ----
        loadWorkoutData();

        // ---- Event Listeners ----
        addBtn.addActionListener(e -> addWorkout());
        editBtn.addActionListener(e -> editWorkout());
        deleteBtn.addActionListener(e -> deleteWorkout());
        clearBtn.addActionListener(e -> clearForm());
        printBtn.addActionListener(e -> printWorkout());
        searchBtn.addActionListener(e -> searchWorkout());
        refreshBtn.addActionListener(e -> {
            loadWorkoutData();
            populateMemberCombo();
            populateTrainerCombo();
            clearForm();
        });

        // Table selection listener to populate form for editing
        workoutTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = workoutTable.getSelectedRow();
                if (row >= 0) {
                    String workoutId = (String) tableModel.getValueAt(row, 0);
                    WorkoutPlan workout = workoutService.getAllWorkouts().stream()
                            .filter(w -> w.getWorkoutId().equals(workoutId))
                            .findFirst().orElse(null);
                    if (workout != null) {
                        populateForm(workout);
                    }
                }
            }
        });
    }

    /**
     * Populate member combo with all members (ID - Name)
     */
    private void populateMemberCombo() {
        memberCombo.removeAllItems();
        List<Member> members = memberService.getAllMembers();
        for (Member m : members) {
            memberCombo.addItem(m.getId() + " - " + m.getFullName());
        }
        if (members.isEmpty()) {
            memberCombo.addItem("No members");
        }
    }

    /**
     * Populate trainer combo with all trainers (ID - Name)
     */
    private void populateTrainerCombo() {
        trainerCombo.removeAllItems();
        List<Trainer> trainers = trainerService.getAllTrainers();
        for (Trainer t : trainers) {
            trainerCombo.addItem(t.getId() + " - " + t.getFullName());
        }
        if (trainers.isEmpty()) {
            trainerCombo.addItem("No trainers");
        }
    }

    /**
     * Load all workouts into table
     */
    private void loadWorkoutData() {
        tableModel.setRowCount(0);
        List<WorkoutPlan> workouts = workoutService.getAllWorkouts();
        for (WorkoutPlan w : workouts) {
            Member member = memberService.findMemberById(w.getMemberId());
            String memberName = member != null ? member.getFullName() : w.getMemberId();
            // Trainer name can be stored directly, or look up by ID if we store trainer ID
            // In our model, we store trainerName as string, so use that.
            String trainerName = w.getTrainerName();
            tableModel.addRow(new Object[]{
                    w.getWorkoutId(),
                    memberName,
                    trainerName,
                    w.getWorkoutType(),
                    w.getExercise(),
                    w.getSets(),
                    w.getRepetitions(),
                    w.getWeight()
            });
        }
    }

    /**
     * Search workouts by keyword (ID, Member Name, Exercise)
     */
    private void searchWorkout() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) {
            loadWorkoutData();
            return;
        }
        tableModel.setRowCount(0);
        List<WorkoutPlan> all = workoutService.getAllWorkouts();
        List<WorkoutPlan> filtered = all.stream()
                .filter(w -> w.getWorkoutId().toLowerCase().contains(keyword.toLowerCase()) ||
                             w.getMemberId().toLowerCase().contains(keyword.toLowerCase()) ||
                             w.getExercise().toLowerCase().contains(keyword.toLowerCase()))
                .collect(Collectors.toList());
        for (WorkoutPlan w : filtered) {
            Member member = memberService.findMemberById(w.getMemberId());
            String memberName = member != null ? member.getFullName() : w.getMemberId();
            tableModel.addRow(new Object[]{
                    w.getWorkoutId(),
                    memberName,
                    w.getTrainerName(),
                    w.getWorkoutType(),
                    w.getExercise(),
                    w.getSets(),
                    w.getRepetitions(),
                    w.getWeight()
            });
        }
    }

    /**
     * Generate next Workout ID (WO + timestamp)
     */
    private String generateWorkoutId() {
        return "WO" + System.currentTimeMillis();
    }

    /**
     * Clear form and reset editing state
     */
    private void clearForm() {
        workoutIdField.setText("");
        memberCombo.setSelectedIndex(0);
        trainerCombo.setSelectedIndex(0);
        workoutTypeCombo.setSelectedIndex(0);
        exerciseCombo.setSelectedIndex(0);
        setsSpinner.setValue(3);
        repsSpinner.setValue(10);
        weightField.setText("");
        durationSpinner.setValue(30);
        notesArea.setText("");
        currentEditingWorkout = null;
        workoutTable.clearSelection();
        addBtn.setText("Add");
    }

    /**
     * Populate form with data from a WorkoutPlan object
     */
    private void populateForm(WorkoutPlan workout) {
        workoutIdField.setText(workout.getWorkoutId());
        // Set member combo
        String memberId = workout.getMemberId();
        for (int i = 0; i < memberCombo.getItemCount(); i++) {
            String item = memberCombo.getItemAt(i);
            if (item.startsWith(memberId + " - ")) {
                memberCombo.setSelectedIndex(i);
                break;
            }
        }
        // Set trainer combo (by name)
        String trainerName = workout.getTrainerName();
        for (int i = 0; i < trainerCombo.getItemCount(); i++) {
            String item = trainerCombo.getItemAt(i);
            if (item.endsWith(" - " + trainerName) || item.equals(trainerName)) {
                trainerCombo.setSelectedIndex(i);
                break;
            }
        }
        workoutTypeCombo.setSelectedItem(workout.getWorkoutType());
        exerciseCombo.setSelectedItem(workout.getExercise());
        setsSpinner.setValue(workout.getSets());
        repsSpinner.setValue(workout.getRepetitions());
        weightField.setText(String.valueOf(workout.getWeight()));
        durationSpinner.setValue(workout.getDurationMinutes());
        notesArea.setText(workout.getNotes());
        currentEditingWorkout = workout;
        addBtn.setText("Update");
    }

    /**
     * Validate form fields
     */
    private boolean validateForm() {
        if (memberCombo.getSelectedIndex() == -1 || memberCombo.getSelectedItem().equals("No members")) {
            JOptionPane.showMessageDialog(this, "Please select a member.");
            return false;
        }
        if (trainerCombo.getSelectedIndex() == -1 || trainerCombo.getSelectedItem().equals("No trainers")) {
            JOptionPane.showMessageDialog(this, "Please select a trainer.");
            return false;
        }
        String weightStr = weightField.getText().trim();
        if (!weightStr.isEmpty() && !ValidationUtils.isPositiveNumber(weightStr)) {
            JOptionPane.showMessageDialog(this, "Weight must be a positive number.");
            weightField.requestFocus();
            return false;
        }
        return true;
    }

    /**
     * Add new workout
     */
    private void addWorkout() {
        if (!validateForm()) return;

        String memberItem = (String) memberCombo.getSelectedItem();
        String memberId = memberItem.split(" - ")[0];
        String trainerItem = (String) trainerCombo.getSelectedItem();
        String trainerName = trainerItem.split(" - ")[1]; // format "ID - Name"

        WorkoutPlan workout = new WorkoutPlan();
        workout.setWorkoutId(generateWorkoutId());
        workout.setMemberId(memberId);
        workout.setMemberName(memberService.findMemberById(memberId).getFullName());
        workout.setTrainerName(trainerName);
        workout.setWorkoutType((String) workoutTypeCombo.getSelectedItem());
        workout.setExercise((String) exerciseCombo.getSelectedItem());
        workout.setSets((int) setsSpinner.getValue());
        workout.setRepetitions((int) repsSpinner.getValue());
        workout.setWeight(weightField.getText().trim().isEmpty() ? 0 : Double.parseDouble(weightField.getText().trim()));
        workout.setDurationMinutes((int) durationSpinner.getValue());
        workout.setNotes(notesArea.getText().trim());

        workoutService.addWorkout(workout);
        JOptionPane.showMessageDialog(this, "Workout plan added successfully.");
        loadWorkoutData();
        clearForm();
    }

    /**
     * Edit existing workout
     */
    private void editWorkout() {
        if (currentEditingWorkout == null) {
            JOptionPane.showMessageDialog(this, "Please select a workout from the table to edit.");
            return;
        }
        if (!validateForm()) return;

        String memberItem = (String) memberCombo.getSelectedItem();
        String memberId = memberItem.split(" - ")[0];
        String trainerItem = (String) trainerCombo.getSelectedItem();
        String trainerName = trainerItem.split(" - ")[1];

        currentEditingWorkout.setMemberId(memberId);
        currentEditingWorkout.setMemberName(memberService.findMemberById(memberId).getFullName());
        currentEditingWorkout.setTrainerName(trainerName);
        currentEditingWorkout.setWorkoutType((String) workoutTypeCombo.getSelectedItem());
        currentEditingWorkout.setExercise((String) exerciseCombo.getSelectedItem());
        currentEditingWorkout.setSets((int) setsSpinner.getValue());
        currentEditingWorkout.setRepetitions((int) repsSpinner.getValue());
        currentEditingWorkout.setWeight(weightField.getText().trim().isEmpty() ? 0 : Double.parseDouble(weightField.getText().trim()));
        currentEditingWorkout.setDurationMinutes((int) durationSpinner.getValue());
        currentEditingWorkout.setNotes(notesArea.getText().trim());

        workoutService.updateWorkout(currentEditingWorkout);
        JOptionPane.showMessageDialog(this, "Workout plan updated successfully.");
        loadWorkoutData();
        clearForm();
    }

    /**
     * Delete selected workout
     */
    private void deleteWorkout() {
        int row = workoutTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a workout to delete.");
            return;
        }
        String workoutId = (String) tableModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete workout " + workoutId + "?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            workoutService.deleteWorkout(workoutId);
            JOptionPane.showMessageDialog(this, "Workout deleted.");
            loadWorkoutData();
            clearForm();
        }
    }

    /**
     * Print the selected workout plan
     */
    private void printWorkout() {
        int row = workoutTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a workout to print.");
            return;
        }
        String workoutId = (String) tableModel.getValueAt(row, 0);
        WorkoutPlan workout = workoutService.getAllWorkouts().stream()
                .filter(w -> w.getWorkoutId().equals(workoutId))
                .findFirst().orElse(null);
        if (workout == null) return;

        Member member = memberService.findMemberById(workout.getMemberId());
        String memberName = member != null ? member.getFullName() : workout.getMemberId();

        StringBuilder sb = new StringBuilder();
        sb.append("=====================================\n");
        sb.append("           FITZONE\n");
        sb.append("        WORKOUT PLAN\n");
        sb.append("=====================================\n\n");
        sb.append("Workout ID: ").append(workout.getWorkoutId()).append("\n");
        sb.append("Member: ").append(memberName).append("\n");
        sb.append("Trainer: ").append(workout.getTrainerName()).append("\n");
        sb.append("Type: ").append(workout.getWorkoutType()).append("\n");
        sb.append("Exercise: ").append(workout.getExercise()).append("\n");
        sb.append("Sets: ").append(workout.getSets()).append("\n");
        sb.append("Repetitions: ").append(workout.getRepetitions()).append("\n");
        sb.append("Weight: ").append(workout.getWeight()).append(" kg\n");
        sb.append("Duration: ").append(workout.getDurationMinutes()).append(" min\n");
        sb.append("Notes: ").append(workout.getNotes()).append("\n");
        sb.append("\n-------------------------------------\n");
        sb.append("Train Hard. Stay Strong. Live Better.\n");
        sb.append("=====================================\n");

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scroll = new JScrollPane(textArea);
        scroll.setPreferredSize(new Dimension(400, 400));
        JOptionPane.showMessageDialog(this, scroll, "Workout Plan Print", JOptionPane.PLAIN_MESSAGE);
    }
}