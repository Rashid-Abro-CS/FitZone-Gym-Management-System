package com.fitzone.service;

import com.fitzone.model.Trainer;
import com.fitzone.util.FileManager;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class TrainerService {
    private List<Trainer> trainers;
    private final String filePath = "data/trainers.dat";

    public TrainerService() {
        trainers = FileManager.loadData(filePath);
        if (trainers == null) trainers = new ArrayList<>();
    }

    public List<Trainer> getAllTrainers() { return trainers; }

    public void addTrainer(Trainer t) {
        trainers.add(t);
        FileManager.saveData(trainers, filePath);
    }

    public void updateTrainer(Trainer t) {
        for (int i = 0; i < trainers.size(); i++) {
            if (trainers.get(i).getId().equals(t.getId())) {
                trainers.set(i, t);
                FileManager.saveData(trainers, filePath);
                break;
            }
        }
    }

    public void deleteTrainer(String id) {
        trainers.removeIf(t -> t.getId().equals(id));
        FileManager.saveData(trainers, filePath);
    }

    public Trainer findTrainerById(String id) {
        return trainers.stream().filter(t -> t.getId().equals(id)).findFirst().orElse(null);
    }

    public List<Trainer> searchTrainers(String keyword) {
        String lower = keyword.toLowerCase();
        return trainers.stream()
                .filter(t -> t.getId().toLowerCase().contains(lower) ||
                             t.getFullName().toLowerCase().contains(lower) ||
                             t.getSpecialization().toLowerCase().contains(lower))
                .collect(Collectors.toList());
    }

    public long getTotalTrainers() { return trainers.size(); }
    public long getActiveTrainers() {
        return trainers.stream().filter(t -> "Active".equals(t.getStatus())).count();
    }
}