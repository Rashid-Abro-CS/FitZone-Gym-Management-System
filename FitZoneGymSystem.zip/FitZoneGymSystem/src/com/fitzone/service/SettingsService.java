package com.fitzone.service;

import com.fitzone.model.GymSettings;
import com.fitzone.util.FileManager;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles loading, saving, and validating GymSettings.
 * Settings are stored as a single-element list in data/settings.dat
 * so it can reuse FileManager's generic list-based persistence.
 */
public class SettingsService {
    private final String filePath = "data/settings.dat";
    private GymSettings settings;

    public SettingsService() {
        List<GymSettings> loaded = FileManager.loadData(filePath);
        if (loaded != null && !loaded.isEmpty()) {
            settings = loaded.get(0);
        } else {
            settings = new GymSettings();
            settings.setAdminPassword(hashPassword("admin123"));
            saveSettings(settings);
        }
    }

    public GymSettings loadSettings() {
        return settings;
    }

    public void saveSettings(GymSettings newSettings) {
        this.settings = newSettings;
        List<GymSettings> list = new ArrayList<>();
        list.add(newSettings);
        FileManager.saveData(list, filePath);
    }

    /**
     * Hashes a plain text password using SHA-256.
     */
    public String hashPassword(String plainText) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(plainText.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException | java.io.UnsupportedEncodingException e) {
            // Fallback (should not happen with SHA-256/UTF-8)
            return String.valueOf(plainText.hashCode());
        }
    }

    /**
     * Validates a plain text password against the currently stored admin password.
     */
    public boolean validateAdminPassword(String plainText) {
        if (settings == null || settings.getAdminPassword() == null) {
            return false;
        }
        return settings.getAdminPassword().equals(hashPassword(plainText));
    }
}
