package com.fitzone.gui;

import com.fitzone.model.Member;
import com.fitzone.model.Payment;
import com.fitzone.model.Attendance;
import com.fitzone.service.MemberService;
import com.fitzone.service.PaymentService;
import com.fitzone.service.AttendanceService;
import com.fitzone.util.DateUtils;
import com.fitzone.util.ImageUtils;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Notifications Panel - FitZone Gym Management System
 * Displays important alerts and system notifications.
 */
public class NotificationPanel extends JPanel {

    private MemberService memberService;
    private PaymentService paymentService;
    private AttendanceService attendanceService;

    private JList<Notification> notificationList;
    private DefaultListModel<Notification> listModel;
    private JButton refreshBtn, clearBtn;

    // Icons for different notification types
    private ImageIcon warningIcon;
    private ImageIcon infoIcon;
    private ImageIcon successIcon;

    public NotificationPanel() {
        memberService = new MemberService();
        paymentService = new PaymentService();
        attendanceService = new AttendanceService();

        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(45, 45, 45));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Load icons
        warningIcon = ImageUtils.loadImage("resources/warning.png", 24, 24);
        infoIcon = ImageUtils.loadImage("resources/info.png", 24, 24);
        successIcon = ImageUtils.loadImage("resources/success.png", 24, 24);
        // If icons missing, use emojis via text renderer fallback.

        // Title
        JLabel titleLabel = new JLabel("NOTIFICATIONS", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        add(titleLabel, BorderLayout.NORTH);

        // Center: Notification list
        listModel = new DefaultListModel<>();
        notificationList = new JList<>(listModel);
        notificationList.setCellRenderer(new NotificationCellRenderer());
        notificationList.setBackground(new Color(50, 50, 50));
        notificationList.setForeground(Color.WHITE);
        notificationList.setSelectionBackground(new Color(200, 50, 50));
        notificationList.setSelectionForeground(Color.WHITE);
        notificationList.setFixedCellHeight(50);

        JScrollPane scrollPane = new JScrollPane(notificationList);
        scrollPane.getViewport().setBackground(new Color(45, 45, 45));
        add(scrollPane, BorderLayout.CENTER);

        // Bottom: Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        buttonPanel.setOpaque(false);

        refreshBtn = new JButton("Refresh");
        refreshBtn.setBackground(new Color(70, 130, 180));
        refreshBtn.setForeground(Color.WHITE);
        refreshBtn.setFocusPainted(false);

        clearBtn = new JButton("Clear All");
        clearBtn.setBackground(new Color(200, 50, 50));
        clearBtn.setForeground(Color.WHITE);
        clearBtn.setFocusPainted(false);

        buttonPanel.add(refreshBtn);
        buttonPanel.add(clearBtn);
        add(buttonPanel, BorderLayout.SOUTH);

        // Load initial notifications
        generateNotifications();

        // Event listeners
        refreshBtn.addActionListener(e -> generateNotifications());
        clearBtn.addActionListener(e -> {
            listModel.clear();
            JOptionPane.showMessageDialog(this, "All notifications cleared.");
        });
    }

    /**
     * Generate notifications based on current system data.
     */
    private void generateNotifications() {
        listModel.clear();

        // 1. Expiring memberships (within 7 days)
        List<Member> allMembers = memberService.getAllMembers();
        LocalDate today = LocalDate.now();
        LocalDate weekLater = today.plusDays(7);

        List<Member> expiringSoon = new ArrayList<>();
        List<Member> expired = new ArrayList<>();
        for (Member m : allMembers) {
            LocalDate expiry = m.getMembershipExpiryDate();
            if (expiry != null) {
                if (expiry.isBefore(today)) {
                    expired.add(m);
                } else if (expiry.isBefore(weekLater) || expiry.equals(weekLater)) {
                    expiringSoon.add(m);
                }
            }
        }

        if (!expiringSoon.isEmpty()) {
            String msg = "⚠ " + expiringSoon.size() + " membership(s) expiring within 7 days: ";
            for (int i = 0; i < Math.min(3, expiringSoon.size()); i++) {
                msg += expiringSoon.get(i).getFullName();
                if (i < Math.min(3, expiringSoon.size()) - 1) msg += ", ";
            }
            if (expiringSoon.size() > 3) msg += " and " + (expiringSoon.size() - 3) + " more.";
            listModel.addElement(new Notification(Notification.Type.WARNING, msg));
        }

        if (!expired.isEmpty()) {
            String msg = "❌ " + expired.size() + " membership(s) have expired. Please renew.";
            listModel.addElement(new Notification(Notification.Type.WARNING, msg));
        }

        // 2. Pending payments
        List<Payment> allPayments = paymentService.getAllPayments();
        long pending = allPayments.stream()
                .filter(p -> "Pending".equals(p.getStatus()) || "Partial".equals(p.getStatus()))
                .count();
        if (pending > 0) {
            String msg = "💳 " + pending + " payment(s) are pending or partially paid.";
            listModel.addElement(new Notification(Notification.Type.WARNING, msg));
        }

        // 3. Today's attendance
        List<Attendance> todayAtt = attendanceService.getTodayAttendance();
        long present = todayAtt.stream().filter(a -> "Present".equals(a.getStatus())).count();
        long absent = todayAtt.stream().filter(a -> "Absent".equals(a.getStatus())).count();
        if (present > 0 || absent > 0) {
            String msg = "📅 Today's attendance: " + present + " present, " + absent + " absent.";
            listModel.addElement(new Notification(Notification.Type.INFO, msg));
        } else {
            listModel.addElement(new Notification(Notification.Type.INFO, "📅 No attendance records for today yet."));
        }

        // 4. New members joined today
        long newToday = allMembers.stream()
                .filter(m -> m.getJoinDate() != null && m.getJoinDate().equals(today))
                .count();
        if (newToday > 0) {
            String msg = "✅ " + newToday + " new member(s) registered today.";
            listModel.addElement(new Notification(Notification.Type.SUCCESS, msg));
        }

        // 5. Total members and trainers stats (optional)
        long totalMembers = memberService.getTotalMembers();
        long totalTrainers = memberService.getAllMembers().stream()
                .map(Member::getTrainer)
                .filter(t -> t != null)
                .distinct()
                .count();
        String statsMsg = "📊 Total Members: " + totalMembers + " | Total Trainers: " + totalTrainers;
        listModel.addElement(new Notification(Notification.Type.INFO, statsMsg));

        // If no notifications (unlikely), add a placeholder
        if (listModel.isEmpty()) {
            listModel.addElement(new Notification(Notification.Type.SUCCESS, "✅ All systems normal. No pending issues."));
        }
    }

    /**
     * Notification data class.
     */
    private static class Notification {
        enum Type { WARNING, INFO, SUCCESS }
        Type type;
        String message;

        Notification(Type type, String message) {
            this.type = type;
            this.message = message;
        }

        @Override
        public String toString() {
            return message;
        }
    }

    /**
     * Custom cell renderer to display icon + message with colors.
     */
    private class NotificationCellRenderer extends JPanel implements ListCellRenderer<Notification> {
        private JLabel iconLabel;
        private JLabel textLabel;

        public NotificationCellRenderer() {
            setLayout(new BorderLayout(10, 0));
            setOpaque(true);
            setBackground(new Color(50, 50, 50));
            setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

            iconLabel = new JLabel();
            iconLabel.setHorizontalAlignment(SwingConstants.CENTER);
            iconLabel.setPreferredSize(new Dimension(30, 30));
            add(iconLabel, BorderLayout.WEST);

            textLabel = new JLabel();
            textLabel.setFont(new Font("Arial", Font.PLAIN, 14));
            textLabel.setForeground(Color.WHITE);
            add(textLabel, BorderLayout.CENTER);
        }

        @Override
        public Component getListCellRendererComponent(JList<? extends Notification> list,
                                                      Notification value, int index,
                                                      boolean isSelected, boolean cellHasFocus) {
            // Set icon based on type
            ImageIcon icon = null;
            Color bg = new Color(50, 50, 50);
            switch (value.type) {
                case WARNING:
                    icon = warningIcon;
                    textLabel.setForeground(Color.ORANGE);
                    bg = new Color(60, 40, 20);
                    break;
                case SUCCESS:
                    icon = successIcon;
                    textLabel.setForeground(Color.GREEN);
                    bg = new Color(20, 60, 30);
                    break;
                case INFO:
                default:
                    icon = infoIcon;
                    textLabel.setForeground(Color.CYAN);
                    bg = new Color(20, 40, 60);
                    break;
            }

            if (icon != null) {
                iconLabel.setIcon(icon);
            } else {
                // Fallback to emoji
                String emoji = "ℹ️";
                if (value.type == Notification.Type.WARNING) emoji = "⚠️";
                else if (value.type == Notification.Type.SUCCESS) emoji = "✅";
                iconLabel.setText(emoji);
                iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
            }

            textLabel.setText(value.message);

            if (isSelected) {
                setBackground(new Color(200, 50, 50));
            } else {
                setBackground(bg);
            }

            return this;
        }
    }
}