package com.fitzone.service;

import com.fitzone.model.WorkoutPlan;
import com.fitzone.util.FileManager;
import java.util.ArrayList;
import java.util.List;

public class WorkoutService {
    private List<WorkoutPlan> workouts;
    private final String filePath = "data/workouts.dat";

    public WorkoutService() {
        workouts = FileManager.loadData(filePath);
        if (workouts == null) workouts = new ArrayList<>();
    }

    public List<WorkoutPlan> getAllWorkouts() { return workouts; }

    public void addWorkout(WorkoutPlan w) {
        workouts.add(w);
        FileManager.saveData(workouts, filePath);
    }

    public void updateWorkout(WorkoutPlan w) {
        for (int i = 0; i < workouts.size(); i++) {
            if (workouts.get(i).getWorkoutId().equals(w.getWorkoutId())) {
                workouts.set(i, w);
                FileManager.saveData(workouts, filePath);
                break;
            }
        }
    }

    public void deleteWorkout(String id) {
        workouts.removeIf(w -> w.getWorkoutId().equals(id));
        FileManager.saveData(workouts, filePath);
    }

    public List<WorkoutPlan> getWorkoutsForMember(String memberId) {
        List<WorkoutPlan> result = new ArrayList<>();
        for (WorkoutPlan w : workouts) {
            if (w.getMemberId().equals(memberId)) result.add(w);
        }
        return result;
    }
}