package com.fitzone.service;

import com.fitzone.model.Attendance;
import com.fitzone.util.FileManager;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class AttendanceService {
    private List<Attendance> attendances;
    private final String filePath = "data/attendance.dat";

    public AttendanceService() {
        attendances = FileManager.loadData(filePath);
        if (attendances == null) attendances = new ArrayList<>();
    }

    public List<Attendance> getAllAttendances() { return attendances; }

    public void addAttendance(Attendance a) {
        attendances.add(a);
        FileManager.saveData(attendances, filePath);
    }

    public void updateAttendance(Attendance a) {
        for (int i = 0; i < attendances.size(); i++) {
            if (attendances.get(i).getAttendanceId().equals(a.getAttendanceId())) {
                attendances.set(i, a);
                FileManager.saveData(attendances, filePath);
                break;
            }
        }
    }

    public void deleteAttendance(String id) {
        attendances.removeIf(a -> a.getAttendanceId().equals(id));
        FileManager.saveData(attendances, filePath);
    }

    public List<Attendance> getTodayAttendance() {
        LocalDate today = LocalDate.now();
        return attendances.stream()
                .filter(a -> a.getDate().equals(today))
                .collect(Collectors.toList());
    }

    public long getTodayPresent() {
        return getTodayAttendance().stream().filter(a -> "Present".equals(a.getStatus())).count();
    }

    public long getTodayAbsent() {
        return getTodayAttendance().stream().filter(a -> "Absent".equals(a.getStatus())).count();
    }
}