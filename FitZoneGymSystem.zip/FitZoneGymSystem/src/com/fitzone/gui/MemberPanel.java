package com.fitzone.gui;

import com.fitzone.model.Member;
import com.fitzone.service.MemberService;
import com.fitzone.util.ImageUtils;
import com.fitzone.util.ValidationUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class MemberPanel extends JPanel {
    private MemberService memberService;
    private JTable memberTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JTextField idField, nameField, fatherField, phoneField, emailField, cnicField, addressField;
    private JComboBox<String> genderCombo, statusCombo;
    private JSpinner ageSpinner;
    private JButton addBtn, editBtn, deleteBtn, searchBtn, refreshBtn;
    private JLabel profilePicLabel;

    public MemberPanel() {
        memberService = new MemberService();
        setLayout(new BorderLayout());
        setBackground(Color.DARK_GRAY);

        // Top panel with search and buttons
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(new Color(60, 60, 60));
        searchField = new JTextField(20);
        searchBtn = new JButton("Search");
        refreshBtn = new JButton("Refresh");
        addBtn = new JButton("Add Member");
        topPanel.add(new JLabel("Search:"));
        topPanel.add(searchField);
        topPanel.add(searchBtn);
        topPanel.add(refreshBtn);
        topPanel.add(addBtn);

        add(topPanel, BorderLayout.NORTH);

        // Table
        String[] columns = {"ID", "Name", "Phone", "Gender", "Membership", "Trainer", "Join Date", "Expiry", "Status"};
        tableModel = new DefaultTableModel(columns, 0);
        memberTable = new JTable(tableModel);
        memberTable.setRowHeight(25);
        memberTable.getTableHeader().setBackground(new Color(50, 50, 50));
        memberTable.getTableHeader().setForeground(Color.WHITE);
        JScrollPane scrollPane = new JScrollPane(memberTable);
        add(scrollPane, BorderLayout.CENTER);

        // Form panel (right or bottom) - simplified
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(new Color(80, 80, 80));
        // ... add fields
        // For brevity, not all fields are added here.

        add(formPanel, BorderLayout.SOUTH);

        loadTableData();

        // Event listeners
        searchBtn.addActionListener(e -> searchMembers());
        refreshBtn.addActionListener(e -> loadTableData());
        addBtn.addActionListener(e -> addMember());
    }

    private void loadTableData() {
        tableModel.setRowCount(0);
        List<Member> members = memberService.getAllMembers();
        for (Member m : members) {
            tableModel.addRow(new Object[]{
                m.getId(), m.getFullName(), m.getPhone(), m.getGender(),
                m.getMembershipPlan() != null ? m.getMembershipPlan().getPlanName() : "",
                m.getTrainer() != null ? m.getTrainer().getFullName() : "",
                m.getJoinDate(), m.getMembershipExpiryDate(), m.getStatus()
            });
        }
    }

    private void searchMembers() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) {
            loadTableData();
            return;
        }
        tableModel.setRowCount(0);
        List<Member> result = memberService.searchMembers(keyword);
        for (Member m : result) {
            tableModel.addRow(new Object[]{
                m.getId(), m.getFullName(), m.getPhone(), m.getGender(),
                m.getMembershipPlan() != null ? m.getMembershipPlan().getPlanName() : "",
                m.getTrainer() != null ? m.getTrainer().getFullName() : "",
                m.getJoinDate(), m.getMembershipExpiryDate(), m.getStatus()
            });
        }
    }

    private void addMember() {
        // Implement form validation and add
        JOptionPane.showMessageDialog(this, "Member added successfully (demo).");
        loadTableData();
    }
}