package com.fitzone.gui;

import com.fitzone.model.Member;
import com.fitzone.model.MembershipPlan;
import com.fitzone.model.Payment;
import com.fitzone.service.MemberService;
import com.fitzone.service.PaymentService;
import com.fitzone.service.MembershipPlanService;
import com.fitzone.util.DateUtils;
import com.fitzone.util.ImageUtils;
import com.fitzone.util.ValidationUtils;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

public class PaymentPanel extends JPanel {

    private PaymentService paymentService;
    private MemberService memberService;
    private MembershipPlanService planService;

    // Table components
    private JTable paymentTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JButton searchBtn, refreshBtn, addBtn, editBtn, deleteBtn, clearBtn, printBtn;

    // Form fields
    private JTextField paymentIdField;
    private JComboBox<String> memberCombo;
    private JTextField memberNameField; // auto-filled
    private JTextField planNameField;   // auto-filled
    private JTextField amountField;
    private JTextField dueAmountField;
    private JComboBox<String> methodCombo;
    private JComboBox<String> statusCombo;
    private JFormattedTextField dateField; // use JTextField for simplicity

    // For editing
    private Payment currentEditingPayment = null;

    public PaymentPanel() {
        paymentService = new PaymentService();
        memberService = new MemberService();
        planService = new MembershipPlanService();

        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(45, 45, 45));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // ---- Top: Title and search ----
        JPanel topPanel = new JPanel(new BorderLayout(10, 5));
        topPanel.setOpaque(false);

        JLabel titleLabel = new JLabel("PAYMENT MANAGEMENT", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        topPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setOpaque(false);
        searchPanel.add(new JLabel("Search:"));
        searchField = new JTextField(20);
        searchPanel.add(searchField);
        searchBtn = new JButton("Search");
        searchBtn.setBackground(new Color(70, 130, 180));
        searchBtn.setForeground(Color.WHITE);
        searchBtn.setFocusPainted(false);
        refreshBtn = new JButton("Refresh");
        refreshBtn.setBackground(new Color(100, 100, 100));
        refreshBtn.setForeground(Color.WHITE);
        refreshBtn.setFocusPainted(false);
        searchPanel.add(searchBtn);
        searchPanel.add(refreshBtn);

        topPanel.add(searchPanel, BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        // ---- Center: Table ----
        String[] columns = {"Payment ID", "Member ID", "Member Name", "Plan", "Amount (Rs.)", "Date", "Method", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        paymentTable = new JTable(tableModel);
        paymentTable.setRowHeight(25);
        paymentTable.getTableHeader().setBackground(new Color(60, 60, 60));
        paymentTable.getTableHeader().setForeground(Color.WHITE);
        paymentTable.setBackground(new Color(50, 50, 50));
        paymentTable.setForeground(Color.WHITE);
        paymentTable.setSelectionBackground(new Color(200, 50, 50));
        paymentTable.setSelectionForeground(Color.WHITE);
        paymentTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        paymentTable.setFont(new Font("Arial", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(paymentTable);
        scrollPane.getViewport().setBackground(new Color(45, 45, 45));
        add(scrollPane, BorderLayout.CENTER);

        // ---- Bottom: Form and buttons ----
        JPanel bottomPanel = new JPanel(new BorderLayout(10, 10));
        bottomPanel.setOpaque(false);

        // Form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 1),
                "Payment Details",
                TitledBorder.CENTER,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                Color.WHITE
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Payment ID (auto-generated, read-only)
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Payment ID:"), gbc);
        gbc.gridx = 1;
        paymentIdField = new JTextField(15);
        paymentIdField.setEditable(false);
        paymentIdField.setBackground(new Color(60, 60, 60));
        paymentIdField.setForeground(Color.WHITE);
        formPanel.add(paymentIdField, gbc);

        // Member selection
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Member:"), gbc);
        gbc.gridx = 1;
        memberCombo = new JComboBox<>();
        memberCombo.setPreferredSize(new Dimension(150, 25));
        populateMemberCombo();
        formPanel.add(memberCombo, gbc);

        // Member Name (auto-filled, read-only)
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Member Name:"), gbc);
        gbc.gridx = 1;
        memberNameField = new JTextField(15);
        memberNameField.setEditable(false);
        memberNameField.setBackground(new Color(60, 60, 60));
        memberNameField.setForeground(Color.WHITE);
        formPanel.add(memberNameField, gbc);

        // Membership Plan (auto-filled)
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(new JLabel("Membership Plan:"), gbc);
        gbc.gridx = 1;
        planNameField = new JTextField(15);
        planNameField.setEditable(false);
        planNameField.setBackground(new Color(60, 60, 60));
        planNameField.setForeground(Color.WHITE);
        formPanel.add(planNameField, gbc);

        // Amount
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(new JLabel("Amount (Rs.):"), gbc);
        gbc.gridx = 1;
        amountField = new JTextField(15);
        formPanel.add(amountField, gbc);

        // Due Amount (for partial payments)
        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(new JLabel("Due Amount (Rs.):"), gbc);
        gbc.gridx = 1;
        dueAmountField = new JTextField(15);
        dueAmountField.setText("0");
        formPanel.add(dueAmountField, gbc);

        // Payment Date
        gbc.gridx = 0;
        gbc.gridy = 6;
        formPanel.add(new JLabel("Payment Date:"), gbc);
        gbc.gridx = 1;
        dateField = new JFormattedTextField(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        dateField.setValue(LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        dateField.setColumns(15);
        formPanel.add(dateField, gbc);

        // Payment Method
        gbc.gridx = 0;
        gbc.gridy = 7;
        formPanel.add(new JLabel("Payment Method:"), gbc);
        gbc.gridx = 1;
        methodCombo = new JComboBox<>(new String[]{"Cash", "Bank Transfer", "EasyPaisa", "JazzCash", "Card"});
        formPanel.add(methodCombo, gbc);

        // Status
        gbc.gridx = 0;
        gbc.gridy = 8;
        formPanel.add(new JLabel("Status:"), gbc);
        gbc.gridx = 1;
        statusCombo = new JComboBox<>(new String[]{"Paid", "Partial", "Pending"});
        formPanel.add(statusCombo, gbc);

        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        buttonPanel.setOpaque(false);

        addBtn = new JButton("Add");
        addBtn.setBackground(new Color(0, 150, 0));
        addBtn.setForeground(Color.WHITE);
        addBtn.setFocusPainted(false);
        addBtn.setIcon(ImageUtils.loadImage("resources/payment.png", 20, 20));

        editBtn = new JButton("Edit");
        editBtn.setBackground(new Color(200, 160, 0));
        editBtn.setForeground(Color.WHITE);
        editBtn.setFocusPainted(false);

        deleteBtn = new JButton("Delete");
        deleteBtn.setBackground(new Color(200, 50, 50));
        deleteBtn.setForeground(Color.WHITE);
        deleteBtn.setFocusPainted(false);

        clearBtn = new JButton("Clear");
        clearBtn.setBackground(new Color(100, 100, 100));
        clearBtn.setForeground(Color.WHITE);
        clearBtn.setFocusPainted(false);

        printBtn = new JButton("Print Receipt");
        printBtn.setBackground(new Color(70, 130, 180));
        printBtn.setForeground(Color.WHITE);
        printBtn.setFocusPainted(false);

        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(clearBtn);
        buttonPanel.add(printBtn);

        // Add form and buttons to bottom panel
        bottomPanel.add(formPanel, BorderLayout.CENTER);
        bottomPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(bottomPanel, BorderLayout.SOUTH);

        // ---- Load data ----
        loadPaymentData();

        // ---- Event Listeners ----
        addBtn.addActionListener(e -> addPayment());
        editBtn.addActionListener(e -> editPayment());
        deleteBtn.addActionListener(e -> deletePayment());
        clearBtn.addActionListener(e -> clearForm());
        printBtn.addActionListener(e -> printReceipt());
        searchBtn.addActionListener(e -> searchPayment());
        refreshBtn.addActionListener(e -> {
            loadPaymentData();
            populateMemberCombo();
            clearForm();
        });

        // Member selection auto-fill member name and plan
        memberCombo.addActionListener(e -> {
            String selected = (String) memberCombo.getSelectedItem();
            if (selected != null && !selected.equals("No members")) {
                String memberId = selected.split(" - ")[0];
                Member m = memberService.findMemberById(memberId);
                if (m != null) {
                    memberNameField.setText(m.getFullName());
                    MembershipPlan plan = m.getMembershipPlan();
                    if (plan != null) {
                        planNameField.setText(plan.getPlanName());
                        // Optionally auto-fill amount
                        amountField.setText(String.valueOf(plan.getFee()));
                    } else {
                        planNameField.setText("");
                    }
                }
            } else {
                memberNameField.setText("");
                planNameField.setText("");
            }
        });

        // Table selection listener to populate form for editing
        paymentTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = paymentTable.getSelectedRow();
                if (row >= 0) {
                    String paymentId = (String) tableModel.getValueAt(row, 0);
                    Payment payment = paymentService.getAllPayments().stream()
                            .filter(p -> p.getPaymentId().equals(paymentId))
                            .findFirst().orElse(null);
                    if (payment != null) {
                        populateForm(payment);
                    }
                }
            }
        });
    }

    /**
     * Populate member combo with all members (ID - Name)
     */
    private void populateMemberCombo() {
        memberCombo.removeAllItems();
        List<Member> members = memberService.getAllMembers();
        for (Member m : members) {
            memberCombo.addItem(m.getId() + " - " + m.getFullName());
        }
        if (members.isEmpty()) {
            memberCombo.addItem("No members");
        }
    }

    /**
     * Load all payments into table
     */
    private void loadPaymentData() {
        tableModel.setRowCount(0);
        List<Payment> payments = paymentService.getAllPayments();
        for (Payment p : payments) {
            tableModel.addRow(new Object[]{
                    p.getPaymentId(),
                    p.getMemberId(),
                    p.getMemberName(),
                    p.getMembershipPlan(),
                    p.getAmount(),
                    DateUtils.formatDate(p.getPaymentDate()),
                    p.getPaymentMethod(),
                    p.getStatus()
            });
        }
    }

    /**
     * Search payments by keyword (Payment ID, Member ID, Member Name)
     */
    private void searchPayment() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) {
            loadPaymentData();
            return;
        }
        tableModel.setRowCount(0);
        List<Payment> filtered = paymentService.searchPayments(keyword);
        for (Payment p : filtered) {
            tableModel.addRow(new Object[]{
                    p.getPaymentId(),
                    p.getMemberId(),
                    p.getMemberName(),
                    p.getMembershipPlan(),
                    p.getAmount(),
                    DateUtils.formatDate(p.getPaymentDate()),
                    p.getPaymentMethod(),
                    p.getStatus()
            });
        }
    }

    /**
     * Generate next Payment ID (PAY + timestamp)
     */
    private String generatePaymentId() {
        return "PAY" + System.currentTimeMillis();
    }

    /**
     * Clear form and reset editing state
     */
    private void clearForm() {
        paymentIdField.setText("");
        memberCombo.setSelectedIndex(0);
        memberNameField.setText("");
        planNameField.setText("");
        amountField.setText("");
        dueAmountField.setText("0");
        dateField.setValue(LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        methodCombo.setSelectedIndex(0);
        statusCombo.setSelectedIndex(0);
        currentEditingPayment = null;
        paymentTable.clearSelection();
        addBtn.setText("Add");
    }

    /**
     * Populate form with data from a Payment object
     */
    private void populateForm(Payment payment) {
        paymentIdField.setText(payment.getPaymentId());
        // Set member combo
        String memberId = payment.getMemberId();
        for (int i = 0; i < memberCombo.getItemCount(); i++) {
            String item = memberCombo.getItemAt(i);
            if (item.startsWith(memberId + " - ")) {
                memberCombo.setSelectedIndex(i);
                break;
            }
        }
        memberNameField.setText(payment.getMemberName());
        planNameField.setText(payment.getMembershipPlan());
        amountField.setText(String.valueOf(payment.getAmount()));
        dueAmountField.setText(String.valueOf(payment.getDueAmount()));
        dateField.setValue(DateUtils.formatDate(payment.getPaymentDate()));
        methodCombo.setSelectedItem(payment.getPaymentMethod());
        statusCombo.setSelectedItem(payment.getStatus());
        currentEditingPayment = payment;
        addBtn.setText("Update");
    }

    /**
     * Validate form fields
     */
    private boolean validateForm() {
        if (memberCombo.getSelectedIndex() == -1 || memberCombo.getSelectedItem().equals("No members")) {
            JOptionPane.showMessageDialog(this, "Please select a member.");
            return false;
        }
        if (!ValidationUtils.isPositiveNumber(amountField.getText().trim())) {
            JOptionPane.showMessageDialog(this, "Amount must be a positive number.");
            return false;
        }
        if (!ValidationUtils.isPositiveNumber(dueAmountField.getText().trim())) {
            JOptionPane.showMessageDialog(this, "Due amount must be a non-negative number.");
            return false;
        }
        // Date validation: just ensure it's not empty
        if (dateField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a valid date.");
            return false;
        }
        return true;
    }

    /**
     * Add new payment
     */
    private void addPayment() {
        if (!validateForm()) return;

        String memberItem = (String) memberCombo.getSelectedItem();
        String memberId = memberItem.split(" - ")[0];
        Member member = memberService.findMemberById(memberId);
        if (member == null) {
            JOptionPane.showMessageDialog(this, "Member not found.");
            return;
        }

        LocalDate date;
        try {
            date = DateUtils.parseDate(dateField.getText().trim());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid date format. Use dd-MM-yyyy.");
            return;
        }

        Payment payment = new Payment();
        payment.setPaymentId(generatePaymentId());
        payment.setMemberId(memberId);
        payment.setMemberName(member.getFullName());
        payment.setMembershipPlan(planNameField.getText().trim());
        payment.setAmount(Double.parseDouble(amountField.getText().trim()));
        payment.setPaymentDate(date);
        payment.setPaymentMethod((String) methodCombo.getSelectedItem());
        payment.setDueAmount(Double.parseDouble(dueAmountField.getText().trim()));
        payment.setStatus((String) statusCombo.getSelectedItem());

        paymentService.addPayment(payment);
        JOptionPane.showMessageDialog(this, "Payment added successfully.");
        loadPaymentData();
        clearForm();
    }

    /**
     * Edit existing payment
     */
    private void editPayment() {
        if (currentEditingPayment == null) {
            JOptionPane.showMessageDialog(this, "Please select a payment from the table to edit.");
            return;
        }
        if (!validateForm()) return;

        String memberItem = (String) memberCombo.getSelectedItem();
        String memberId = memberItem.split(" - ")[0];
        Member member = memberService.findMemberById(memberId);
        if (member == null) {
            JOptionPane.showMessageDialog(this, "Member not found.");
            return;
        }

        LocalDate date;
        try {
            date = DateUtils.parseDate(dateField.getText().trim());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid date format. Use dd-MM-yyyy.");
            return;
        }

        currentEditingPayment.setMemberId(memberId);
        currentEditingPayment.setMemberName(member.getFullName());
        currentEditingPayment.setMembershipPlan(planNameField.getText().trim());
        currentEditingPayment.setAmount(Double.parseDouble(amountField.getText().trim()));
        currentEditingPayment.setPaymentDate(date);
        currentEditingPayment.setPaymentMethod((String) methodCombo.getSelectedItem());
        currentEditingPayment.setDueAmount(Double.parseDouble(dueAmountField.getText().trim()));
        currentEditingPayment.setStatus((String) statusCombo.getSelectedItem());

        paymentService.updatePayment(currentEditingPayment);
        JOptionPane.showMessageDialog(this, "Payment updated successfully.");
        loadPaymentData();
        clearForm();
    }

    /**
     * Delete selected payment
     */
    private void deletePayment() {
        int row = paymentTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a payment to delete.");
            return;
        }
        String paymentId = (String) tableModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete payment " + paymentId + "?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            paymentService.deletePayment(paymentId);
            JOptionPane.showMessageDialog(this, "Payment deleted.");
            loadPaymentData();
            clearForm();
        }
    }

    /**
     * Print receipt for selected payment
     */
    private void printReceipt() {
        int row = paymentTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a payment to print receipt.");
            return;
        }
        String paymentId = (String) tableModel.getValueAt(row, 0);
        Payment payment = paymentService.getAllPayments().stream()
                .filter(p -> p.getPaymentId().equals(paymentId))
                .findFirst().orElse(null);
        if (payment == null) return;

        // Build receipt
        StringBuilder sb = new StringBuilder();
        sb.append("=====================================\n");
        sb.append("           FITZONE\n");
        sb.append("        GYM MANAGEMENT\n");
        sb.append("=====================================\n\n");
        sb.append("         PAYMENT RECEIPT\n\n");
        sb.append("Receipt No: ").append(payment.getPaymentId()).append("\n");
        sb.append("Date: ").append(DateUtils.formatDate(payment.getPaymentDate())).append("\n\n");
        sb.append("Member ID: ").append(payment.getMemberId()).append("\n");
        sb.append("Member Name: ").append(payment.getMemberName()).append("\n\n");
        sb.append("Membership Plan: ").append(payment.getMembershipPlan()).append("\n");
        sb.append("Amount: Rs. ").append(payment.getAmount()).append("\n");
        sb.append("Due Amount: Rs. ").append(payment.getDueAmount()).append("\n");
        sb.append("Payment Method: ").append(payment.getPaymentMethod()).append("\n");
        sb.append("Payment Status: ").append(payment.getStatus()).append("\n");
        sb.append("\n-------------------------------------\n");
        sb.append("Thank you for choosing FitZone!\n");
        sb.append("Train Hard. Stay Strong. Live Better.\n");
        sb.append("=====================================\n");

        // Show receipt in a dialog with text area
        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scroll = new JScrollPane(textArea);
        scroll.setPreferredSize(new Dimension(450, 450));
        JOptionPane.showMessageDialog(this, scroll, "Payment Receipt", JOptionPane.PLAIN_MESSAGE);
    }
}