package com.fitzone.model;

import java.io.Serializable;

// Abstraction
public abstract class Person implements Serializable {
    private static final long serialVersionUID = 1L;

    // Encapsulation: private fields
    private String id;
    private String fullName;
    private String gender;
    private int age;
    private String phone;
    private String email;
    private String address;
    private String profilePicturePath;

    // Default constructor
    public Person() {}

    public Person(String id, String fullName, String gender, int age, String phone, String email, String address) {
        this.id = id;
        this.fullName = fullName;
        this.gender = gender;
        this.age = age;
        this.phone = phone;
        this.email = email;
        this.address = address;
    }

    // Getters and Setters (Encapsulation)
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getProfilePicturePath() { return profilePicturePath; }
    public void setProfilePicturePath(String profilePicturePath) { this.profilePicturePath = profilePicturePath; }

    // Polymorphism: method to be overridden
    public abstract String displayInfo();
}