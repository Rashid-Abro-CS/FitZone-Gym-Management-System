package com.fitzone.util;

public class ValidationUtils {

    public static boolean isValidPhone(String phone) {
        return phone.matches("03\\d{2}-?\\d{7}");
    }

    public static boolean isValidCNIC(String cnic) {
        return cnic.matches("\\d{5}-?\\d{7}-?\\d{1}");
    }

    public static boolean isValidEmail(String email) {
        return email.matches("^[A-Za-z0-9+_.-]+@(.+)$");
    }

    public static boolean isPositiveNumber(String str) {
        try {
            double d = Double.parseDouble(str);
            return d > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static boolean isInteger(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static boolean isNotEmpty(String str) {
        return str != null && !str.trim().isEmpty();
    }
}