package com.fitzone.gui;

import com.fitzone.util.ImageUtils;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JCheckBox showPasswordCheck;
    private JCheckBox rememberMeCheck;

    public LoginFrame() {
        setTitle("FitZone Login");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // Background panel with image
        JPanel bgPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon bg = ImageUtils.loadImage("resources/login-bg.jpg", getWidth(), getHeight());
                if (bg != null) g.drawImage(bg.getImage(), 0, 0, this);
            }
        };
        bgPanel.setLayout(new GridBagLayout());
        setContentPane(bgPanel);

        // Login card
        JPanel card = new JPanel();
        card.setBackground(new Color(0, 0, 0, 180));
        card.setPreferredSize(new Dimension(350, 350));
        card.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Logo
        JLabel logoLabel = new JLabel("FITZONE");
        logoLabel.setFont(new Font("Arial", Font.BOLD, 30));
        logoLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        card.add(logoLabel, gbc);

        JLabel subLabel = new JLabel("GYM MANAGEMENT SYSTEM");
        subLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        subLabel.setForeground(Color.LIGHT_GRAY);
        gbc.gridy = 1;
        card.add(subLabel, gbc);

        // Username
        gbc.gridwidth = 1;
        gbc.gridy = 2;
        gbc.gridx = 0;
        JLabel userLabel = new JLabel("Username:");
        userLabel.setForeground(Color.WHITE);
        card.add(userLabel, gbc);
        usernameField = new JTextField(15);
        gbc.gridx = 1;
        card.add(usernameField, gbc);

        // Password
        gbc.gridy = 3;
        gbc.gridx = 0;
        JLabel passLabel = new JLabel("Password:");
        passLabel.setForeground(Color.WHITE);
        card.add(passLabel, gbc);
        passwordField = new JPasswordField(15);
        gbc.gridx = 1;
        card.add(passwordField, gbc);

        // Show Password
        showPasswordCheck = new JCheckBox("Show Password");
        showPasswordCheck.setForeground(Color.WHITE);
        showPasswordCheck.setOpaque(false);
        gbc.gridy = 4;
        gbc.gridx = 1;
        card.add(showPasswordCheck, gbc);

        // Remember Me
        rememberMeCheck = new JCheckBox("Remember Username");
        rememberMeCheck.setForeground(Color.WHITE);
        rememberMeCheck.setOpaque(false);
        gbc.gridy = 5;
        gbc.gridx = 1;
        card.add(rememberMeCheck, gbc);

        // Buttons
        JButton loginBtn = new JButton("LOGIN");
        loginBtn.setBackground(new Color(220, 50, 50));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFocusPainted(false);
        JButton clearBtn = new JButton("CLEAR");
        clearBtn.setBackground(Color.DARK_GRAY);
        clearBtn.setForeground(Color.WHITE);
        JButton exitBtn = new JButton("EXIT");
        exitBtn.setBackground(Color.DARK_GRAY);
        exitBtn.setForeground(Color.WHITE);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        btnPanel.setOpaque(false);
        btnPanel.add(loginBtn);
        btnPanel.add(clearBtn);
        btnPanel.add(exitBtn);
        gbc.gridy = 6;
        gbc.gridx = 0; gbc.gridwidth = 2;
        card.add(btnPanel, gbc);

        // Add card to bg panel
        bgPanel.add(card);

        // Event listeners
        loginBtn.addActionListener(e -> login());
        clearBtn.addActionListener(e -> clearFields());
        exitBtn.addActionListener(e -> System.exit(0));

        showPasswordCheck.addActionListener(e -> {
            if (showPasswordCheck.isSelected()) {
                passwordField.setEchoChar((char) 0);
            } else {
                passwordField.setEchoChar('*');
            }
        });

        // Load remembered username
        if (rememberMeCheck.isSelected()) {
            // would load from settings; skip for brevity
        }
    }

    private void login() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        // Hardcoded for demo
        if ("admin".equals(username) && "admin123".equals(password)) {
            JOptionPane.showMessageDialog(this, "Welcome to FitZone Gym Management System!");
            dispose();
            new DashboardFrame().setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        usernameField.setText("");
        passwordField.setText("");
    }
}