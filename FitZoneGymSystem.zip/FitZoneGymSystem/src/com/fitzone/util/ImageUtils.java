package com.fitzone.util;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class ImageUtils {

    public static ImageIcon loadImage(String path, int width, int height) {
        try {
            BufferedImage img = ImageIO.read(new File(path));
            if (img == null) {
                return createPlaceholder(width, height);
            }
            Image scaled = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            return new ImageIcon(scaled);
        } catch (IOException e) {
            return createPlaceholder(width, height);
        }
    }

    public static ImageIcon loadImage(String path) {
        return loadImage(path, 50, 50);
    }

    public static ImageIcon createPlaceholder(int width, int height) {
        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = img.createGraphics();
        g2d.setColor(Color.DARK_GRAY);
        g2d.fillRect(0, 0, width, height);
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.BOLD, 12));
        g2d.drawString("No Image", 10, height/2);
        g2d.dispose();
        return new ImageIcon(img);
    }

    public static ImageIcon resizeImage(ImageIcon icon, int width, int height) {
        Image img = icon.getImage();
        Image scaled = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(scaled);
    }

    // Rounded image not implemented fully; can be added.
}