package com.fitzone.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

// Inheritance: Member extends Person
public class Member extends Person {
    private static final long serialVersionUID = 1L;

    private String fatherName;
    private String cnic;
    private LocalDate dob;
    private LocalDate joinDate;
    private MembershipPlan membershipPlan;
    private Trainer trainer; // Composition
    private double weight;
    private double height;
    private String emergencyContact;
    private LocalDate membershipStartDate;
    private LocalDate membershipExpiryDate;
    private String status; // Active, Expired, Suspended, Expiring Soon

    public Member() {
        super();
    }

    // Constructor
    public Member(String id, String fullName, String fatherName, String gender, int age, LocalDate dob,
                  String phone, String email, String cnic, String address, LocalDate joinDate,
                  MembershipPlan membershipPlan, Trainer trainer, double weight, double height,
                  String emergencyContact, LocalDate membershipStartDate, LocalDate membershipExpiryDate,
                  String status, String profilePicturePath) {
        super(id, fullName, gender, age, phone, email, address);
        this.fatherName = fatherName;
        this.cnic = cnic;
        this.dob = dob;
        this.joinDate = joinDate;
        this.membershipPlan = membershipPlan;
        this.trainer = trainer;
        this.weight = weight;
        this.height = height;
        this.emergencyContact = emergencyContact;
        this.membershipStartDate = membershipStartDate;
        this.membershipExpiryDate = membershipExpiryDate;
        this.status = status;
        setProfilePicturePath(profilePicturePath);
    }

    // Getters and Setters
    public String getFatherName() { return fatherName; }
    public void setFatherName(String fatherName) { this.fatherName = fatherName; }

    public String getCnic() { return cnic; }
    public void setCnic(String cnic) { this.cnic = cnic; }

    public LocalDate getDob() { return dob; }
    public void setDob(LocalDate dob) { this.dob = dob; }

    public LocalDate getJoinDate() { return joinDate; }
    public void setJoinDate(LocalDate joinDate) { this.joinDate = joinDate; }

    public MembershipPlan getMembershipPlan() { return membershipPlan; }
    public void setMembershipPlan(MembershipPlan membershipPlan) { this.membershipPlan = membershipPlan; }

    public Trainer getTrainer() { return trainer; }
    public void setTrainer(Trainer trainer) { this.trainer = trainer; }

    public double getWeight() { return weight; }
    public void setWeight(double weight) { this.weight = weight; }

    public double getHeight() { return height; }
    public void setHeight(double height) { this.height = height; }

    public String getEmergencyContact() { return emergencyContact; }
    public void setEmergencyContact(String emergencyContact) { this.emergencyContact = emergencyContact; }

    public LocalDate getMembershipStartDate() { return membershipStartDate; }
    public void setMembershipStartDate(LocalDate membershipStartDate) { this.membershipStartDate = membershipStartDate; }

    public LocalDate getMembershipExpiryDate() { return membershipExpiryDate; }
    public void setMembershipExpiryDate(LocalDate membershipExpiryDate) { this.membershipExpiryDate = membershipExpiryDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    // Polymorphism: override displayInfo
    @Override
    public String displayInfo() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        return "Member ID: " + getId() +
               "\nName: " + getFullName() +
               "\nMembership: " + (membershipPlan != null ? membershipPlan.getPlanName() : "None") +
               "\nExpiry: " + (membershipExpiryDate != null ? membershipExpiryDate.format(formatter) : "N/A") +
               "\nStatus: " + status;
    }

    // Calculate BMI
    public double calculateBMI() {
        if (height <= 0) return 0;
        double heightInMeters = height / 100.0;
        return weight / (heightInMeters * heightInMeters);
    }
}