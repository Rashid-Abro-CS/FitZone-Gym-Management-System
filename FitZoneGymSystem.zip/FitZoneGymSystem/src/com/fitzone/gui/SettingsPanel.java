package com.fitzone.gui;

import com.fitzone.model.GymSettings;
import com.fitzone.service.SettingsService;
import com.fitzone.util.ImageUtils;
import com.fitzone.util.ValidationUtils;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Settings Panel - FitZone Gym Management System
 * Allows configuration of gym details, admin credentials, theme, and more.
 */
public class SettingsPanel extends JPanel {

    private SettingsService settingsService;
    private GymSettings currentSettings;

    // Form fields
    private JTextField gymNameField;
    private JTextArea gymAddressArea;
    private JTextField gymPhoneField;
    private JTextField gymEmailField;
    private JTextField adminNameField;
    private JTextField adminUsernameField;
    private JComboBox<String> themeCombo;

    private JButton saveBtn, resetBtn, changePasswordBtn;

    public SettingsPanel() {
        settingsService = new SettingsService();
        currentSettings = settingsService.loadSettings();

        setLayout(new BorderLayout(15, 15));
        setBackground(new Color(45, 45, 45));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // ---- Title ----
        JLabel titleLabel = new JLabel("SETTINGS", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        add(titleLabel, BorderLayout.NORTH);

        // ---- Center: Settings form ----
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 1),
                "Gym Configuration",
                TitledBorder.CENTER,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 16),
                Color.WHITE
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;

        // Gym Name
        formPanel.add(new JLabel("Gym Name:"), gbc);
        gbc.gridx = 1;
        gymNameField = new JTextField(25);
        formPanel.add(gymNameField, gbc);

        // Gym Address (textarea)
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Gym Address:"), gbc);
        gbc.gridx = 1;
        gymAddressArea = new JTextArea(3, 25);
        gymAddressArea.setLineWrap(true);
        gymAddressArea.setWrapStyleWord(true);
        JScrollPane addressScroll = new JScrollPane(gymAddressArea);
        addressScroll.setPreferredSize(new Dimension(250, 60));
        formPanel.add(addressScroll, gbc);

        // Gym Phone
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Gym Phone:"), gbc);
        gbc.gridx = 1;
        gymPhoneField = new JTextField(25);
        formPanel.add(gymPhoneField, gbc);

        // Gym Email
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(new JLabel("Gym Email:"), gbc);
        gbc.gridx = 1;
        gymEmailField = new JTextField(25);
        formPanel.add(gymEmailField, gbc);

        // Admin Name
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(new JLabel("Admin Name:"), gbc);
        gbc.gridx = 1;
        adminNameField = new JTextField(25);
        formPanel.add(adminNameField, gbc);

        // Admin Username
        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(new JLabel("Admin Username:"), gbc);
        gbc.gridx = 1;
        adminUsernameField = new JTextField(25);
        formPanel.add(adminUsernameField, gbc);

        // Theme
        gbc.gridx = 0;
        gbc.gridy = 6;
        formPanel.add(new JLabel("Theme:"), gbc);
        gbc.gridx = 1;
        themeCombo = new JComboBox<>(new String[]{"Dark Gym Theme", "Light Theme"});
        formPanel.add(themeCombo, gbc);

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        buttonPanel.setOpaque(false);

        saveBtn = new JButton("Save Settings");
        saveBtn.setBackground(new Color(0, 150, 0));
        saveBtn.setForeground(Color.WHITE);
        saveBtn.setFocusPainted(false);
        saveBtn.setIcon(ImageUtils.loadImage("resources/settings.png", 20, 20));

        resetBtn = new JButton("Reset Defaults");
        resetBtn.setBackground(new Color(200, 160, 0));
        resetBtn.setForeground(Color.WHITE);
        resetBtn.setFocusPainted(false);

        changePasswordBtn = new JButton("Change Password");
        changePasswordBtn.setBackground(new Color(70, 130, 180));
        changePasswordBtn.setForeground(Color.WHITE);
        changePasswordBtn.setFocusPainted(false);

        buttonPanel.add(saveBtn);
        buttonPanel.add(resetBtn);
        buttonPanel.add(changePasswordBtn);

        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(buttonPanel, gbc);

        add(formPanel, BorderLayout.CENTER);

        // ---- Footer ----
        JLabel footer = new JLabel("All settings are saved locally in data/settings.dat", SwingConstants.CENTER);
        footer.setFont(new Font("Arial", Font.ITALIC, 12));
        footer.setForeground(Color.LIGHT_GRAY);
        footer.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        add(footer, BorderLayout.SOUTH);

        // ---- Populate fields with current settings ----
        populateFields();

        // ---- Event listeners ----
        saveBtn.addActionListener(e -> saveSettings());
        resetBtn.addActionListener(e -> resetToDefaults());
        changePasswordBtn.addActionListener(e -> showChangePasswordDialog());

        // Apply theme on selection change (preview)
        themeCombo.addActionListener(e -> applyTheme());
    }

    /**
     * Populate form fields with current settings.
     */
    private void populateFields() {
        if (currentSettings != null) {
            gymNameField.setText(currentSettings.getGymName());
            gymAddressArea.setText(currentSettings.getGymAddress());
            gymPhoneField.setText(currentSettings.getGymPhone());
            gymEmailField.setText(currentSettings.getGymEmail());
            adminNameField.setText(currentSettings.getAdminName());
            adminUsernameField.setText(currentSettings.getAdminUsername());
            themeCombo.setSelectedItem(currentSettings.getTheme());
        } else {
            // Default settings if none loaded
            gymNameField.setText("FitZone Gym");
            gymAddressArea.setText("123 Fitness Street, City");
            gymPhoneField.setText("03XX-XXXXXXX");
            gymEmailField.setText("info@fitzone.com");
            adminNameField.setText("Admin");
            adminUsernameField.setText("admin");
            themeCombo.setSelectedIndex(0);
        }
    }

    /**
     * Save settings to file.
     */
    private void saveSettings() {
        // Validate fields (basic)
        if (gymNameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Gym Name is required.");
            gymNameField.requestFocus();
            return;
        }
        if (adminNameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Admin Name is required.");
            adminNameField.requestFocus();
            return;
        }
        if (adminUsernameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Admin Username is required.");
            adminUsernameField.requestFocus();
            return;
        }
        String phone = gymPhoneField.getText().trim();
        if (!phone.isEmpty() && !ValidationUtils.isValidPhone(phone)) {
            JOptionPane.showMessageDialog(this, "Invalid phone format. Use 03XX-XXXXXXX or 03XXXXXXXXX.");
            gymPhoneField.requestFocus();
            return;
        }
        String email = gymEmailField.getText().trim();
        if (!email.isEmpty() && !ValidationUtils.isValidEmail(email)) {
            JOptionPane.showMessageDialog(this, "Invalid email format.");
            gymEmailField.requestFocus();
            return;
        }

        // Create settings object
        GymSettings settings = new GymSettings();
        settings.setGymName(gymNameField.getText().trim());
        settings.setGymAddress(gymAddressArea.getText().trim());
        settings.setGymPhone(phone);
        settings.setGymEmail(email);
        settings.setAdminName(adminNameField.getText().trim());
        settings.setAdminUsername(adminUsernameField.getText().trim());
        settings.setTheme((String) themeCombo.getSelectedItem());

        // Save
        settingsService.saveSettings(settings);
        currentSettings = settings;
        JOptionPane.showMessageDialog(this, "Settings saved successfully.");
    }

    /**
     * Reset to default settings.
     */
    private void resetToDefaults() {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to reset all settings to defaults?",
                "Confirm Reset",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            GymSettings defaults = new GymSettings();
            defaults.setGymName("FitZone Gym");
            defaults.setGymAddress("123 Fitness Street, City");
            defaults.setGymPhone("03XX-XXXXXXX");
            defaults.setGymEmail("info@fitzone.com");
            defaults.setAdminName("Admin");
            defaults.setAdminUsername("admin");
            defaults.setTheme("Dark Gym Theme");

            settingsService.saveSettings(defaults);
            currentSettings = defaults;
            populateFields();
            applyTheme();
            JOptionPane.showMessageDialog(this, "Settings reset to defaults.");
        }
    }

    /**
     * Show dialog to change admin password.
     */
    private void showChangePasswordDialog() {
        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        JPasswordField currentPass = new JPasswordField(15);
        JPasswordField newPass = new JPasswordField(15);
        JPasswordField confirmPass = new JPasswordField(15);

        panel.add(new JLabel("Current Password:"));
        panel.add(currentPass);
        panel.add(new JLabel("New Password:"));
        panel.add(newPass);
        panel.add(new JLabel("Confirm Password:"));
        panel.add(confirmPass);

        int option = JOptionPane.showConfirmDialog(this, panel, "Change Password",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (option == JOptionPane.OK_OPTION) {
            String current = new String(currentPass.getPassword());
            String newPwd = new String(newPass.getPassword());
            String confirm = new String(confirmPass.getPassword());

            // Validate current password (should match stored)
            if (!settingsService.validateAdminPassword(current)) {
                JOptionPane.showMessageDialog(this, "Current password is incorrect.");
                return;
            }
            if (newPwd.isEmpty() || newPwd.length() < 6) {
                JOptionPane.showMessageDialog(this, "New password must be at least 6 characters.");
                return;
            }
            if (!newPwd.equals(confirm)) {
                JOptionPane.showMessageDialog(this, "New passwords do not match.");
                return;
            }

            // Update password in settings
            currentSettings.setAdminPassword(settingsService.hashPassword(newPwd));
            settingsService.saveSettings(currentSettings);
            JOptionPane.showMessageDialog(this, "Password changed successfully.");
        }
    }

    /**
     * Apply selected theme to the panel (preview).
     * For full app theme, would need to propagate to all panels.
     */
    private void applyTheme() {
        String theme = (String) themeCombo.getSelectedItem();
        if ("Light Theme".equals(theme)) {
            setBackground(Color.WHITE);
            // Change child components? For demo, just change this panel.
            // We could also change borders and labels.
            // For full implementation, we'd set a global theme variable and refresh all panels.
        } else {
            setBackground(new Color(45, 45, 45));
        }
        // Repaint
        revalidate();
        repaint();
    }
}