package com.fitzone.gui;

import com.fitzone.model.DietPlan;
import com.fitzone.model.Member;
import com.fitzone.service.DietService;
import com.fitzone.service.MemberService;
import com.fitzone.util.ImageUtils;
import com.fitzone.util.ValidationUtils;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.stream.Collectors;

public class DietPanel extends JPanel {

    private DietService dietService;
    private MemberService memberService;

    // Table components
    private JTable dietTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JButton searchBtn, refreshBtn, addBtn, editBtn, deleteBtn, clearBtn, printBtn;

    // Form fields
    private JTextField dietIdField;
    private JComboBox<String> memberCombo;
    private JComboBox<String> mealTypeCombo;
    private JTextField foodField;
    private JTextField quantityField;
    private JTextField caloriesField;
    private JTextField proteinField;
    private JTextField carbsField;
    private JTextField fatsField;
    private JTextArea notesArea;

    // For editing
    private DietPlan currentEditingDiet = null;

    public DietPanel() {
        dietService = new DietService();
        memberService = new MemberService();

        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(45, 45, 45));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // ---- Top: Title and search ----
        JPanel topPanel = new JPanel(new BorderLayout(10, 5));
        topPanel.setOpaque(false);

        JLabel titleLabel = new JLabel("DIET PLANS", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        topPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setOpaque(false);
        searchPanel.add(new JLabel("Search:"));
        searchField = new JTextField(20);
        searchPanel.add(searchField);
        searchBtn = new JButton("Search");
        searchBtn.setBackground(new Color(70, 130, 180));
        searchBtn.setForeground(Color.WHITE);
        searchBtn.setFocusPainted(false);
        refreshBtn = new JButton("Refresh");
        refreshBtn.setBackground(new Color(100, 100, 100));
        refreshBtn.setForeground(Color.WHITE);
        refreshBtn.setFocusPainted(false);
        searchPanel.add(searchBtn);
        searchPanel.add(refreshBtn);

        topPanel.add(searchPanel, BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        // ---- Center: Table ----
        String[] columns = {"Diet ID", "Member", "Meal Type", "Food", "Calories", "Protein (g)", "Carbs (g)", "Fats (g)"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        dietTable = new JTable(tableModel);
        dietTable.setRowHeight(25);
        dietTable.getTableHeader().setBackground(new Color(60, 60, 60));
        dietTable.getTableHeader().setForeground(Color.WHITE);
        dietTable.setBackground(new Color(50, 50, 50));
        dietTable.setForeground(Color.WHITE);
        dietTable.setSelectionBackground(new Color(200, 50, 50));
        dietTable.setSelectionForeground(Color.WHITE);
        dietTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        dietTable.setFont(new Font("Arial", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(dietTable);
        scrollPane.getViewport().setBackground(new Color(45, 45, 45));
        add(scrollPane, BorderLayout.CENTER);

        // ---- Bottom: Form and buttons ----
        JPanel bottomPanel = new JPanel(new BorderLayout(10, 10));
        bottomPanel.setOpaque(false);

        // Form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 1),
                "Diet Plan Details",
                TitledBorder.CENTER,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                Color.WHITE
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;

        // Diet ID (auto-generated, read-only)
        formPanel.add(new JLabel("Diet ID:"), gbc);
        gbc.gridx = 1;
        dietIdField = new JTextField(15);
        dietIdField.setEditable(false);
        dietIdField.setBackground(new Color(60, 60, 60));
        dietIdField.setForeground(Color.WHITE);
        formPanel.add(dietIdField, gbc);

        // Member
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Member:"), gbc);
        gbc.gridx = 1;
        memberCombo = new JComboBox<>();
        memberCombo.setPreferredSize(new Dimension(150, 25));
        populateMemberCombo();
        formPanel.add(memberCombo, gbc);

        // Meal Type
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Meal Type:"), gbc);
        gbc.gridx = 1;
        mealTypeCombo = new JComboBox<>(new String[]{
                "Breakfast", "Lunch", "Dinner", "Snack", "Pre-Workout", "Post-Workout"
        });
        formPanel.add(mealTypeCombo, gbc);

        // Food
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(new JLabel("Food:"), gbc);
        gbc.gridx = 1;
        foodField = new JTextField(15);
        formPanel.add(foodField, gbc);

        // Quantity
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(new JLabel("Quantity:"), gbc);
        gbc.gridx = 1;
        quantityField = new JTextField(15);
        formPanel.add(quantityField, gbc);

        // Calories
        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(new JLabel("Calories:"), gbc);
        gbc.gridx = 1;
        caloriesField = new JTextField(15);
        formPanel.add(caloriesField, gbc);

        // Protein
        gbc.gridx = 0;
        gbc.gridy = 6;
        formPanel.add(new JLabel("Protein (g):"), gbc);
        gbc.gridx = 1;
        proteinField = new JTextField(15);
        formPanel.add(proteinField, gbc);

        // Carbs
        gbc.gridx = 0;
        gbc.gridy = 7;
        formPanel.add(new JLabel("Carbohydrates (g):"), gbc);
        gbc.gridx = 1;
        carbsField = new JTextField(15);
        formPanel.add(carbsField, gbc);

        // Fats
        gbc.gridx = 0;
        gbc.gridy = 8;
        formPanel.add(new JLabel("Fats (g):"), gbc);
        gbc.gridx = 1;
        fatsField = new JTextField(15);
        formPanel.add(fatsField, gbc);

        // Notes
        gbc.gridx = 0;
        gbc.gridy = 9;
        formPanel.add(new JLabel("Notes:"), gbc);
        gbc.gridx = 1;
        notesArea = new JTextArea(3, 15);
        notesArea.setLineWrap(true);
        notesArea.setWrapStyleWord(true);
        JScrollPane notesScroll = new JScrollPane(notesArea);
        notesScroll.setPreferredSize(new Dimension(150, 60));
        formPanel.add(notesScroll, gbc);

        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        buttonPanel.setOpaque(false);

        addBtn = new JButton("Add");
        addBtn.setBackground(new Color(0, 150, 0));
        addBtn.setForeground(Color.WHITE);
        addBtn.setFocusPainted(false);
        addBtn.setIcon(ImageUtils.loadImage("resources/diet.png", 20, 20));

        editBtn = new JButton("Edit");
        editBtn.setBackground(new Color(200, 160, 0));
        editBtn.setForeground(Color.WHITE);
        editBtn.setFocusPainted(false);

        deleteBtn = new JButton("Delete");
        deleteBtn.setBackground(new Color(200, 50, 50));
        deleteBtn.setForeground(Color.WHITE);
        deleteBtn.setFocusPainted(false);

        clearBtn = new JButton("Clear");
        clearBtn.setBackground(new Color(100, 100, 100));
        clearBtn.setForeground(Color.WHITE);
        clearBtn.setFocusPainted(false);

        printBtn = new JButton("Print");
        printBtn.setBackground(new Color(70, 130, 180));
        printBtn.setForeground(Color.WHITE);
        printBtn.setFocusPainted(false);

        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(clearBtn);
        buttonPanel.add(printBtn);

        // Add form and buttons to bottom panel
        bottomPanel.add(formPanel, BorderLayout.CENTER);
        bottomPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(bottomPanel, BorderLayout.SOUTH);

        // ---- Load data ----
        loadDietData();

        // ---- Event Listeners ----
        addBtn.addActionListener(e -> addDiet());
        editBtn.addActionListener(e -> editDiet());
        deleteBtn.addActionListener(e -> deleteDiet());
        clearBtn.addActionListener(e -> clearForm());
        printBtn.addActionListener(e -> printDietPlan());
        searchBtn.addActionListener(e -> searchDiet());
        refreshBtn.addActionListener(e -> {
            loadDietData();
            populateMemberCombo();
            clearForm();
        });

        // Table selection listener to populate form for editing
        dietTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = dietTable.getSelectedRow();
                if (row >= 0) {
                    String dietId = (String) tableModel.getValueAt(row, 0);
                    DietPlan diet = dietService.getAllDiets().stream()
                            .filter(d -> d.getDietId().equals(dietId))
                            .findFirst().orElse(null);
                    if (diet != null) {
                        populateForm(diet);
                    }
                }
            }
        });
    }

    /**
     * Populate member combo with all members (ID - Name)
     */
    private void populateMemberCombo() {
        memberCombo.removeAllItems();
        List<Member> members = memberService.getAllMembers();
        for (Member m : members) {
            memberCombo.addItem(m.getId() + " - " + m.getFullName());
        }
        if (members.isEmpty()) {
            memberCombo.addItem("No members");
        }
    }

    /**
     * Load all diet plans into table
     */
    private void loadDietData() {
        tableModel.setRowCount(0);
        List<DietPlan> diets = dietService.getAllDiets();
        for (DietPlan d : diets) {
            Member member = memberService.findMemberById(d.getMemberId());
            String memberName = member != null ? member.getFullName() : d.getMemberId();
            tableModel.addRow(new Object[]{
                    d.getDietId(),
                    memberName,
                    d.getMealType(),
                    d.getFood(),
                    d.getCalories(),
                    d.getProtein(),
                    d.getCarbohydrates(),
                    d.getFats()
            });
        }
    }

    /**
     * Search diet plans by keyword (Diet ID, Member Name, Food)
     */
    private void searchDiet() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) {
            loadDietData();
            return;
        }
        tableModel.setRowCount(0);
        List<DietPlan> all = dietService.getAllDiets();
        List<DietPlan> filtered = all.stream()
                .filter(d -> d.getDietId().toLowerCase().contains(keyword.toLowerCase()) ||
                             d.getMemberId().toLowerCase().contains(keyword.toLowerCase()) ||
                             d.getFood().toLowerCase().contains(keyword.toLowerCase()))
                .collect(Collectors.toList());
        for (DietPlan d : filtered) {
            Member member = memberService.findMemberById(d.getMemberId());
            String memberName = member != null ? member.getFullName() : d.getMemberId();
            tableModel.addRow(new Object[]{
                    d.getDietId(),
                    memberName,
                    d.getMealType(),
                    d.getFood(),
                    d.getCalories(),
                    d.getProtein(),
                    d.getCarbohydrates(),
                    d.getFats()
            });
        }
    }

    /**
     * Generate next Diet ID (DIE + timestamp or counter)
     */
    private String generateDietId() {
        return "DIE" + System.currentTimeMillis();
    }

    /**
     * Clear form and reset editing state
     */
    private void clearForm() {
        dietIdField.setText("");
        memberCombo.setSelectedIndex(0);
        mealTypeCombo.setSelectedIndex(0);
        foodField.setText("");
        quantityField.setText("");
        caloriesField.setText("");
        proteinField.setText("");
        carbsField.setText("");
        fatsField.setText("");
        notesArea.setText("");
        currentEditingDiet = null;
        dietTable.clearSelection();
        addBtn.setText("Add");
    }

    /**
     * Populate form with data from a DietPlan object
     */
    private void populateForm(DietPlan diet) {
        dietIdField.setText(diet.getDietId());
        // Set member combo
        String memberId = diet.getMemberId();
        for (int i = 0; i < memberCombo.getItemCount(); i++) {
            String item = memberCombo.getItemAt(i);
            if (item.startsWith(memberId + " - ")) {
                memberCombo.setSelectedIndex(i);
                break;
            }
        }
        mealTypeCombo.setSelectedItem(diet.getMealType());
        foodField.setText(diet.getFood());
        quantityField.setText(diet.getQuantity());
        caloriesField.setText(String.valueOf(diet.getCalories()));
        proteinField.setText(String.valueOf(diet.getProtein()));
        carbsField.setText(String.valueOf(diet.getCarbohydrates()));
        fatsField.setText(String.valueOf(diet.getFats()));
        notesArea.setText(diet.getNotes());
        currentEditingDiet = diet;
        addBtn.setText("Update");
    }

    /**
     * Validate form fields
     */
    private boolean validateForm() {
        if (memberCombo.getSelectedIndex() == -1 || memberCombo.getSelectedItem().equals("No members")) {
            JOptionPane.showMessageDialog(this, "Please select a member.");
            return false;
        }
        if (foodField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Food is required.");
            return false;
        }
        if (quantityField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Quantity is required.");
            return false;
        }
        if (!ValidationUtils.isInteger(caloriesField.getText().trim()) ||
            Integer.parseInt(caloriesField.getText().trim()) < 0) {
            JOptionPane.showMessageDialog(this, "Calories must be a positive integer.");
            return false;
        }
        if (!ValidationUtils.isPositiveNumber(proteinField.getText().trim())) {
            JOptionPane.showMessageDialog(this, "Protein must be a positive number.");
            return false;
        }
        if (!ValidationUtils.isPositiveNumber(carbsField.getText().trim())) {
            JOptionPane.showMessageDialog(this, "Carbohydrates must be a positive number.");
            return false;
        }
        if (!ValidationUtils.isPositiveNumber(fatsField.getText().trim())) {
            JOptionPane.showMessageDialog(this, "Fats must be a positive number.");
            return false;
        }
        return true;
    }

    /**
     * Add new diet plan
     */
    private void addDiet() {
        if (!validateForm()) return;

        String memberItem = (String) memberCombo.getSelectedItem();
        String memberId = memberItem.split(" - ")[0];

        DietPlan diet = new DietPlan();
        diet.setDietId(generateDietId());
        diet.setMemberId(memberId);
        diet.setMealType((String) mealTypeCombo.getSelectedItem());
        diet.setFood(foodField.getText().trim());
        diet.setQuantity(quantityField.getText().trim());
        diet.setCalories(Integer.parseInt(caloriesField.getText().trim()));
        diet.setProtein(Double.parseDouble(proteinField.getText().trim()));
        diet.setCarbohydrates(Double.parseDouble(carbsField.getText().trim()));
        diet.setFats(Double.parseDouble(fatsField.getText().trim()));
        diet.setNotes(notesArea.getText().trim());

        dietService.addDiet(diet);
        JOptionPane.showMessageDialog(this, "Diet plan added successfully.");
        loadDietData();
        clearForm();
    }

    /**
     * Edit existing diet plan
     */
    private void editDiet() {
        if (currentEditingDiet == null) {
            JOptionPane.showMessageDialog(this, "Please select a diet plan from the table to edit.");
            return;
        }
        if (!validateForm()) return;

        String memberItem = (String) memberCombo.getSelectedItem();
        String memberId = memberItem.split(" - ")[0];

        currentEditingDiet.setMemberId(memberId);
        currentEditingDiet.setMealType((String) mealTypeCombo.getSelectedItem());
        currentEditingDiet.setFood(foodField.getText().trim());
        currentEditingDiet.setQuantity(quantityField.getText().trim());
        currentEditingDiet.setCalories(Integer.parseInt(caloriesField.getText().trim()));
        currentEditingDiet.setProtein(Double.parseDouble(proteinField.getText().trim()));
        currentEditingDiet.setCarbohydrates(Double.parseDouble(carbsField.getText().trim()));
        currentEditingDiet.setFats(Double.parseDouble(fatsField.getText().trim()));
        currentEditingDiet.setNotes(notesArea.getText().trim());

        dietService.updateDiet(currentEditingDiet);
        JOptionPane.showMessageDialog(this, "Diet plan updated successfully.");
        loadDietData();
        clearForm();
    }

    /**
     * Delete selected diet plan
     */
    private void deleteDiet() {
        int row = dietTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a diet plan to delete.");
            return;
        }
        String dietId = (String) tableModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete diet plan " + dietId + "?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            dietService.deleteDiet(dietId);
            JOptionPane.showMessageDialog(this, "Diet plan deleted.");
            loadDietData();
            clearForm();
        }
    }

    /**
     * Print the selected diet plan (simple print dialog)
     */
    private void printDietPlan() {
        int row = dietTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a diet plan to print.");
            return;
        }
        // Build a simple text representation
        String dietId = (String) tableModel.getValueAt(row, 0);
        DietPlan diet = dietService.getAllDiets().stream()
                .filter(d -> d.getDietId().equals(dietId))
                .findFirst().orElse(null);
        if (diet == null) return;

        Member member = memberService.findMemberById(diet.getMemberId());
        String memberName = member != null ? member.getFullName() : diet.getMemberId();

        StringBuilder sb = new StringBuilder();
        sb.append("=====================================\n");
        sb.append("           FITZONE\n");
        sb.append("        DIET PLAN\n");
        sb.append("=====================================\n\n");
        sb.append("Diet ID: ").append(diet.getDietId()).append("\n");
        sb.append("Member: ").append(memberName).append("\n");
        sb.append("Meal Type: ").append(diet.getMealType()).append("\n");
        sb.append("Food: ").append(diet.getFood()).append("\n");
        sb.append("Quantity: ").append(diet.getQuantity()).append("\n");
        sb.append("Calories: ").append(diet.getCalories()).append("\n");
        sb.append("Protein: ").append(diet.getProtein()).append(" g\n");
        sb.append("Carbs: ").append(diet.getCarbohydrates()).append(" g\n");
        sb.append("Fats: ").append(diet.getFats()).append(" g\n");
        sb.append("Notes: ").append(diet.getNotes()).append("\n");
        sb.append("\n-------------------------------------\n");
        sb.append("Train Hard. Stay Strong. Live Better.\n");
        sb.append("=====================================\n");

        // Show in a dialog with text area
        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scroll = new JScrollPane(textArea);
        scroll.setPreferredSize(new Dimension(400, 400));
        JOptionPane.showMessageDialog(this, scroll, "Diet Plan Print", JOptionPane.PLAIN_MESSAGE);
    }
}