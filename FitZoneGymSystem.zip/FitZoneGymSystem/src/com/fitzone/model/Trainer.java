package com.fitzone.model;

import java.time.LocalDate;

public class Trainer extends Person {
    private static final long serialVersionUID = 1L;

    private String specialization;
    private int experienceYears;
    private double salary;
    private LocalDate joiningDate;
    private String status; // Active, Inactive

    public Trainer() {
        super();
    }

    public Trainer(String id, String fullName, String gender, int age, String phone, String email,
                   String address, String specialization, int experienceYears, double salary,
                   LocalDate joiningDate, String status, String profilePicturePath) {
        super(id, fullName, gender, age, phone, email, address);
        this.specialization = specialization;
        this.experienceYears = experienceYears;
        this.salary = salary;
        this.joiningDate = joiningDate;
        this.status = status;
        setProfilePicturePath(profilePicturePath);
    }

    // Getters and Setters
    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }

    public int getExperienceYears() { return experienceYears; }
    public void setExperienceYears(int experienceYears) { this.experienceYears = experienceYears; }

    public double getSalary() { return salary; }
    public void setSalary(double salary) { this.salary = salary; }

    public LocalDate getJoiningDate() { return joiningDate; }
    public void setJoiningDate(LocalDate joiningDate) { this.joiningDate = joiningDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String displayInfo() {
        return "Trainer ID: " + getId() +
               "\nName: " + getFullName() +
               "\nSpecialization: " + specialization +
               "\nExperience: " + experienceYears + " years";
    }
}