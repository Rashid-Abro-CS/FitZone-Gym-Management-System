package com.fitzone.model;

import java.io.Serializable;

public class MembershipPlan implements Serializable {
    private static final long serialVersionUID = 1L;

    private String planId;
    private String planName;
    private int durationMonths; // duration in months
    private double fee;
    private String description;
    private String status; // Active, Inactive

    public MembershipPlan() {}

    public MembershipPlan(String planId, String planName, int durationMonths, double fee, String description, String status) {
        this.planId = planId;
        this.planName = planName;
        this.durationMonths = durationMonths;
        this.fee = fee;
        this.description = description;
        this.status = status;
    }

    // Getters and Setters
    public String getPlanId() { return planId; }
    public void setPlanId(String planId) { this.planId = planId; }

    public String getPlanName() { return planName; }
    public void setPlanName(String planName) { this.planName = planName; }

    public int getDurationMonths() { return durationMonths; }
    public void setDurationMonths(int durationMonths) { this.durationMonths = durationMonths; }

    public double getFee() { return fee; }
    public void setFee(double fee) { this.fee = fee; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return planName + " (" + durationMonths + " months) - Rs. " + fee;
    }
}