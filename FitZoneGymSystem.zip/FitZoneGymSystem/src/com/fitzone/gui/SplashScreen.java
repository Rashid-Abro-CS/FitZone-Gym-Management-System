package com.fitzone.gui;

import javax.swing.*;
import java.awt.*;

public class SplashScreen extends JWindow {
    private JProgressBar progressBar;

    public SplashScreen() {
        setSize(600, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(30, 30, 30));

        JLabel logoLabel = new JLabel("FITZONE", SwingConstants.CENTER);
        logoLabel.setFont(new Font("Arial", Font.BOLD, 48));
        logoLabel.setForeground(Color.WHITE);
        panel.add(logoLabel, BorderLayout.CENTER);

        JLabel subLabel = new JLabel("GYM MANAGEMENT SYSTEM", SwingConstants.CENTER);
        subLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        subLabel.setForeground(Color.LIGHT_GRAY);
        panel.add(subLabel, BorderLayout.SOUTH);

        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
        progressBar.setForeground(Color.RED);
        panel.add(progressBar, BorderLayout.NORTH);

        add(panel);

        // Simulate loading
        new Thread(() -> {
            for (int i = 0; i <= 100; i++) {
                try { Thread.sleep(30); } catch (InterruptedException e) {}
                progressBar.setValue(i);
            }
            dispose();
            SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
        }).start();
    }
}