package com.fitzone.gui;

import com.fitzone.model.*;
import com.fitzone.service.*;
import com.fitzone.util.DateUtils;
import com.fitzone.util.ImageUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

public class ReportPanel extends JPanel {

    private MemberService memberService;
    private TrainerService trainerService;
    private PaymentService paymentService;
    private AttendanceService attendanceService;

    // UI components
    private JComboBox<String> reportTypeCombo;
    private JPanel dynamicInputPanel;
    private JFormattedTextField dateField;
    private JComboBox<String> monthCombo;
    private JComboBox<String> memberCombo;
    private JButton generateBtn, printBtn, saveBtn;
    private JTable reportTable;
    private DefaultTableModel tableModel;
    private JLabel statusLabel;

    public ReportPanel() {
        memberService = new MemberService();
        trainerService = new TrainerService();
        paymentService = new PaymentService();
        attendanceService = new AttendanceService();

        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(45, 45, 45));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // ---- Top panel: Report selection and controls ----
        JPanel topPanel = new JPanel(new BorderLayout(10, 5));
        topPanel.setOpaque(false);

        JLabel titleLabel = new JLabel("REPORTS", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        topPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        controlPanel.setOpaque(false);

        controlPanel.add(new JLabel("Report Type:"));
        reportTypeCombo = new JComboBox<>(new String[]{
                "All Members",
                "Active Members",
                "Expired Members",
                "New Members",
                "All Trainers",
                "Active Trainers",
                "Daily Payments",
                "Monthly Payments",
                "Monthly Revenue",
                "Pending Payments",
                "Daily Attendance",
                "Monthly Attendance",
                "Member Attendance"
        });
        controlPanel.add(reportTypeCombo);

        // Dynamic input panel (for date/month/member selection)
        dynamicInputPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        dynamicInputPanel.setOpaque(false);
        controlPanel.add(dynamicInputPanel);

        generateBtn = new JButton("Generate");
        generateBtn.setBackground(new Color(70, 130, 180));
        generateBtn.setForeground(Color.WHITE);
        generateBtn.setFocusPainted(false);
        controlPanel.add(generateBtn);

        printBtn = new JButton("Print");
        printBtn.setBackground(new Color(100, 100, 100));
        printBtn.setForeground(Color.WHITE);
        printBtn.setFocusPainted(false);
        printBtn.setEnabled(false);
        controlPanel.add(printBtn);

        saveBtn = new JButton("Save");
        saveBtn.setBackground(new Color(100, 100, 100));
        saveBtn.setForeground(Color.WHITE);
        saveBtn.setFocusPainted(false);
        saveBtn.setEnabled(false);
        controlPanel.add(saveBtn);

        // Initialize dynamic inputs
        setupDynamicInputs();

        topPanel.add(controlPanel, BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        // ---- Center: Report table ----
        tableModel = new DefaultTableModel();
        reportTable = new JTable(tableModel);
        reportTable.setRowHeight(25);
        reportTable.getTableHeader().setBackground(new Color(60, 60, 60));
        reportTable.getTableHeader().setForeground(Color.WHITE);
        reportTable.setBackground(new Color(50, 50, 50));
        reportTable.setForeground(Color.WHITE);
        reportTable.setSelectionBackground(new Color(200, 50, 50));
        reportTable.setSelectionForeground(Color.WHITE);
        reportTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        reportTable.setFont(new Font("Arial", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(reportTable);
        scrollPane.getViewport().setBackground(new Color(45, 45, 45));
        add(scrollPane, BorderLayout.CENTER);

        // ---- Bottom: Status ----
        statusLabel = new JLabel("Select a report and click Generate", SwingConstants.CENTER);
        statusLabel.setForeground(Color.LIGHT_GRAY);
        statusLabel.setFont(new Font("Arial", Font.ITALIC, 12));
        statusLabel.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 0));
        add(statusLabel, BorderLayout.SOUTH);

        // ---- Event listeners ----
        reportTypeCombo.addActionListener(e -> updateDynamicInputs());
        generateBtn.addActionListener(e -> generateReport());
        printBtn.addActionListener(e -> printReport());
        saveBtn.addActionListener(e -> saveReport());

        // Set default state
        updateDynamicInputs();
    }

    /**
     * Setup dynamic input components based on report type.
     */
    private void setupDynamicInputs() {
        // Date field (for daily reports)
        dateField = new JFormattedTextField(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        dateField.setColumns(12);
        dateField.setValue(LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));

        // Month combo (for monthly reports)
        monthCombo = new JComboBox<>();
        for (int i = 1; i <= 12; i++) {
            monthCombo.addItem(String.format("%02d", i) + " - " + java.time.Month.of(i).toString());
        }
        monthCombo.setSelectedIndex(LocalDate.now().getMonthValue() - 1);

        // Member combo (for member attendance)
        memberCombo = new JComboBox<>();
        populateMemberCombo();

        // Initially, show nothing
        dynamicInputPanel.removeAll();
        dynamicInputPanel.revalidate();
        dynamicInputPanel.repaint();
    }

    /**
     * Populate member combo with all members.
     */
    private void populateMemberCombo() {
        memberCombo.removeAllItems();
        List<Member> members = memberService.getAllMembers();
        for (Member m : members) {
            memberCombo.addItem(m.getId() + " - " + m.getFullName());
        }
        if (members.isEmpty()) {
            memberCombo.addItem("No members");
        }
    }

    /**
     * Update dynamic input panel based on selected report type.
     */
    private void updateDynamicInputs() {
        dynamicInputPanel.removeAll();
        String selected = (String) reportTypeCombo.getSelectedItem();

        if (selected.startsWith("Daily") || selected.equals("Member Attendance") || selected.equals("Pending Payments")) {
            // Daily reports need date
            dynamicInputPanel.add(new JLabel("Date:"));
            dynamicInputPanel.add(dateField);
        } else if (selected.startsWith("Monthly")) {
            // Monthly reports need month
            dynamicInputPanel.add(new JLabel("Month:"));
            dynamicInputPanel.add(monthCombo);
        } else if (selected.equals("Member Attendance")) {
            // Member attendance needs date and member
            dynamicInputPanel.add(new JLabel("Date:"));
            dynamicInputPanel.add(dateField);
            dynamicInputPanel.add(new JLabel("Member:"));
            dynamicInputPanel.add(memberCombo);
        } else {
            // No extra inputs for other reports
        }

        dynamicInputPanel.revalidate();
        dynamicInputPanel.repaint();
    }

    /**
     * Generate report based on selected type.
     */
    private void generateReport() {
        String selected = (String) reportTypeCombo.getSelectedItem();
        tableModel.setRowCount(0);
        tableModel.setColumnCount(0);
        printBtn.setEnabled(false);
        saveBtn.setEnabled(false);

        switch (selected) {
            case "All Members":
                generateAllMembersReport();
                break;
            case "Active Members":
                generateActiveMembersReport();
                break;
            case "Expired Members":
                generateExpiredMembersReport();
                break;
            case "New Members":
                generateNewMembersReport();
                break;
            case "All Trainers":
                generateAllTrainersReport();
                break;
            case "Active Trainers":
                generateActiveTrainersReport();
                break;
            case "Daily Payments":
                generateDailyPaymentsReport();
                break;
            case "Monthly Payments":
                generateMonthlyPaymentsReport();
                break;
            case "Monthly Revenue":
                generateMonthlyRevenueReport();
                break;
            case "Pending Payments":
                generatePendingPaymentsReport();
                break;
            case "Daily Attendance":
                generateDailyAttendanceReport();
                break;
            case "Monthly Attendance":
                generateMonthlyAttendanceReport();
                break;
            case "Member Attendance":
                generateMemberAttendanceReport();
                break;
            default:
                statusLabel.setText("Unknown report type.");
                return;
        }

        if (tableModel.getRowCount() > 0) {
            printBtn.setEnabled(true);
            saveBtn.setEnabled(true);
            statusLabel.setText("Report generated: " + tableModel.getRowCount() + " rows.");
        } else {
            statusLabel.setText("No data found for this report.");
        }
    }

    // ---- Report generation methods ----

    private void generateAllMembersReport() {
        String[] cols = {"ID", "Name", "Phone", "Membership", "Status", "Expiry"};
        tableModel.setColumnIdentifiers(cols);
        List<Member> members = memberService.getAllMembers();
        for (Member m : members) {
            tableModel.addRow(new Object[]{
                    m.getId(),
                    m.getFullName(),
                    m.getPhone(),
                    m.getMembershipPlan() != null ? m.getMembershipPlan().getPlanName() : "",
                    m.getStatus(),
                    DateUtils.formatDate(m.getMembershipExpiryDate())
            });
        }
    }

    private void generateActiveMembersReport() {
        String[] cols = {"ID", "Name", "Phone", "Membership", "Join Date"};
        tableModel.setColumnIdentifiers(cols);
        List<Member> members = memberService.getAllMembers().stream()
                .filter(m -> "Active".equals(m.getStatus()))
                .collect(Collectors.toList());
        for (Member m : members) {
            tableModel.addRow(new Object[]{
                    m.getId(),
                    m.getFullName(),
                    m.getPhone(),
                    m.getMembershipPlan() != null ? m.getMembershipPlan().getPlanName() : "",
                    DateUtils.formatDate(m.getJoinDate())
            });
        }
    }

    private void generateExpiredMembersReport() {
        String[] cols = {"ID", "Name", "Phone", "Expiry Date"};
        tableModel.setColumnIdentifiers(cols);
        List<Member> members = memberService.getAllMembers().stream()
                .filter(m -> "Expired".equals(m.getStatus()))
                .collect(Collectors.toList());
        for (Member m : members) {
            tableModel.addRow(new Object[]{
                    m.getId(),
                    m.getFullName(),
                    m.getPhone(),
                    DateUtils.formatDate(m.getMembershipExpiryDate())
            });
        }
    }

    private void generateNewMembersReport() {
        String[] cols = {"ID", "Name", "Phone", "Join Date", "Plan"};
        tableModel.setColumnIdentifiers(cols);
        // Members joined in current month
        LocalDate now = LocalDate.now();
        List<Member> members = memberService.getAllMembers().stream()
                .filter(m -> m.getJoinDate() != null &&
                        m.getJoinDate().getMonth() == now.getMonth() &&
                        m.getJoinDate().getYear() == now.getYear())
                .collect(Collectors.toList());
        for (Member m : members) {
            tableModel.addRow(new Object[]{
                    m.getId(),
                    m.getFullName(),
                    m.getPhone(),
                    DateUtils.formatDate(m.getJoinDate()),
                    m.getMembershipPlan() != null ? m.getMembershipPlan().getPlanName() : ""
            });
        }
    }

    private void generateAllTrainersReport() {
        String[] cols = {"ID", "Name", "Specialization", "Experience", "Status"};
        tableModel.setColumnIdentifiers(cols);
        List<Trainer> trainers = trainerService.getAllTrainers();
        for (Trainer t : trainers) {
            tableModel.addRow(new Object[]{
                    t.getId(),
                    t.getFullName(),
                    t.getSpecialization(),
                    t.getExperienceYears(),
                    t.getStatus()
            });
        }
    }

    private void generateActiveTrainersReport() {
        String[] cols = {"ID", "Name", "Specialization", "Experience"};
        tableModel.setColumnIdentifiers(cols);
        List<Trainer> trainers = trainerService.getAllTrainers().stream()
                .filter(t -> "Active".equals(t.getStatus()))
                .collect(Collectors.toList());
        for (Trainer t : trainers) {
            tableModel.addRow(new Object[]{
                    t.getId(),
                    t.getFullName(),
                    t.getSpecialization(),
                    t.getExperienceYears()
            });
        }
    }

    private void generateDailyPaymentsReport() {
        LocalDate date = getDateFromField();
        if (date == null) return;
        String[] cols = {"Payment ID", "Member", "Plan", "Amount", "Method", "Status"};
        tableModel.setColumnIdentifiers(cols);
        List<Payment> payments = paymentService.getAllPayments().stream()
                .filter(p -> p.getPaymentDate().equals(date))
                .collect(Collectors.toList());
        for (Payment p : payments) {
            tableModel.addRow(new Object[]{
                    p.getPaymentId(),
                    p.getMemberName(),
                    p.getMembershipPlan(),
                    p.getAmount(),
                    p.getPaymentMethod(),
                    p.getStatus()
            });
        }
    }

    private void generateMonthlyPaymentsReport() {
        int month = getMonthFromCombo();
        if (month == -1) return;
        String[] cols = {"Payment ID", "Member", "Plan", "Amount", "Date", "Status"};
        tableModel.setColumnIdentifiers(cols);
        List<Payment> payments = paymentService.getAllPayments().stream()
                .filter(p -> p.getPaymentDate().getMonthValue() == month)
                .collect(Collectors.toList());
        for (Payment p : payments) {
            tableModel.addRow(new Object[]{
                    p.getPaymentId(),
                    p.getMemberName(),
                    p.getMembershipPlan(),
                    p.getAmount(),
                    DateUtils.formatDate(p.getPaymentDate()),
                    p.getStatus()
            });
        }
    }

    private void generateMonthlyRevenueReport() {
        int month = getMonthFromCombo();
        if (month == -1) return;
        String[] cols = {"Month", "Total Revenue (Rs.)"};
        tableModel.setColumnIdentifiers(cols);
        // Calculate total for the selected month
        double total = paymentService.getAllPayments().stream()
                .filter(p -> p.getPaymentDate().getMonthValue() == month &&
                        "Paid".equals(p.getStatus()))
                .mapToDouble(Payment::getAmount).sum();
        tableModel.addRow(new Object[]{java.time.Month.of(month).toString(), total});
    }

    private void generatePendingPaymentsReport() {
        LocalDate date = getDateFromField();
        if (date == null) return;
        String[] cols = {"Payment ID", "Member", "Amount", "Due", "Status"};
        tableModel.setColumnIdentifiers(cols);
        List<Payment> payments = paymentService.getAllPayments().stream()
                .filter(p -> ("Pending".equals(p.getStatus()) || "Partial".equals(p.getStatus())) &&
                        p.getPaymentDate().equals(date))
                .collect(Collectors.toList());
        for (Payment p : payments) {
            tableModel.addRow(new Object[]{
                    p.getPaymentId(),
                    p.getMemberName(),
                    p.getAmount(),
                    p.getDueAmount(),
                    p.getStatus()
            });
        }
    }

    private void generateDailyAttendanceReport() {
        LocalDate date = getDateFromField();
        if (date == null) return;
        String[] cols = {"Member ID", "Member Name", "Check-In", "Check-Out", "Status"};
        tableModel.setColumnIdentifiers(cols);
        List<Attendance> records = attendanceService.getAllAttendances().stream()
                .filter(a -> a.getDate().equals(date))
                .collect(Collectors.toList());
        for (Attendance a : records) {
            tableModel.addRow(new Object[]{
                    a.getMemberId(),
                    a.getMemberName(),
                    a.getCheckInTime() != null ? a.getCheckInTime().toString() : "",
                    a.getCheckOutTime() != null ? a.getCheckOutTime().toString() : "",
                    a.getStatus()
            });
        }
    }

    private void generateMonthlyAttendanceReport() {
        int month = getMonthFromCombo();
        if (month == -1) return;
        String[] cols = {"Member ID", "Member Name", "Present Days", "Absent Days", "Attendance %"};
        tableModel.setColumnIdentifiers(cols);
        // Group by member
        List<Attendance> all = attendanceService.getAllAttendances().stream()
                .filter(a -> a.getDate().getMonthValue() == month)
                .collect(Collectors.toList());
        // Get distinct members
        List<String> memberIds = all.stream().map(Attendance::getMemberId).distinct().collect(Collectors.toList());
        for (String id : memberIds) {
            List<Attendance> memberAtt = all.stream().filter(a -> a.getMemberId().equals(id)).collect(Collectors.toList());
            long present = memberAtt.stream().filter(a -> "Present".equals(a.getStatus())).count();
            long absent = memberAtt.stream().filter(a -> "Absent".equals(a.getStatus())).count();
            double percent = (present + absent) > 0 ? (present * 100.0 / (present + absent)) : 0;
            Member m = memberService.findMemberById(id);
            String name = m != null ? m.getFullName() : id;
            tableModel.addRow(new Object[]{id, name, present, absent, String.format("%.1f%%", percent)});
        }
    }

    private void generateMemberAttendanceReport() {
        LocalDate date = getDateFromField();
        if (date == null) return;
        String memberItem = (String) memberCombo.getSelectedItem();
        if (memberItem == null || memberItem.equals("No members")) {
            JOptionPane.showMessageDialog(this, "Please select a member.");
            return;
        }
        String memberId = memberItem.split(" - ")[0];
        Member member = memberService.findMemberById(memberId);
        if (member == null) {
            JOptionPane.showMessageDialog(this, "Member not found.");
            return;
        }

        // For the selected date, show attendance record for that member
        String[] cols = {"Date", "Check-In", "Check-Out", "Status"};
        tableModel.setColumnIdentifiers(cols);
        List<Attendance> records = attendanceService.getAllAttendances().stream()
                .filter(a -> a.getMemberId().equals(memberId) && a.getDate().equals(date))
                .collect(Collectors.toList());
        if (records.isEmpty()) {
            tableModel.addRow(new Object[]{DateUtils.formatDate(date), "-", "-", "No record"});
        } else {
            for (Attendance a : records) {
                tableModel.addRow(new Object[]{
                        DateUtils.formatDate(a.getDate()),
                        a.getCheckInTime() != null ? a.getCheckInTime().toString() : "",
                        a.getCheckOutTime() != null ? a.getCheckOutTime().toString() : "",
                        a.getStatus()
                });
            }
        }
    }

    // ---- Helper methods ----

    private LocalDate getDateFromField() {
        try {
            return DateUtils.parseDate(dateField.getText().trim());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid date format. Use dd-MM-yyyy.");
            return null;
        }
    }

    private int getMonthFromCombo() {
        String selected = (String) monthCombo.getSelectedItem();
        if (selected == null) return -1;
        String[] parts = selected.split(" - ");
        return Integer.parseInt(parts[0]);
    }

    // ---- Print and Save ----

    private void printReport() {
        try {
            boolean printed = reportTable.print(JTable.PrintMode.FIT_WIDTH);
            if (printed) {
                statusLabel.setText("Report printed successfully.");
            } else {
                statusLabel.setText("Print cancelled.");
            }
        } catch (java.awt.print.PrinterException e) {
            JOptionPane.showMessageDialog(this, "Print error: " + e.getMessage());
            statusLabel.setText("Print error.");
        }
    }

    private void saveReport() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Save Report");
        chooser.setSelectedFile(new java.io.File("report.csv"));
        int choice = chooser.showSaveDialog(this);
        if (choice != JFileChooser.APPROVE_OPTION) return;

        java.io.File file = chooser.getSelectedFile();
        if (!file.getPath().toLowerCase().endsWith(".csv")) {
            file = new java.io.File(file.getPath() + ".csv");
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {
            // Write header
            for (int i = 0; i < tableModel.getColumnCount(); i++) {
                writer.print(tableModel.getColumnName(i));
                if (i < tableModel.getColumnCount() - 1) writer.print(",");
            }
            writer.println();

            // Write rows
            for (int r = 0; r < tableModel.getRowCount(); r++) {
                for (int c = 0; c < tableModel.getColumnCount(); c++) {
                    Object val = tableModel.getValueAt(r, c);
                    writer.print(val != null ? val.toString() : "");
                    if (c < tableModel.getColumnCount() - 1) writer.print(",");
                }
                writer.println();
            }
            statusLabel.setText("Report saved to " + file.getName());
            JOptionPane.showMessageDialog(this, "Report saved successfully.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving report: " + e.getMessage());
            statusLabel.setText("Save error.");
        }
    }
}