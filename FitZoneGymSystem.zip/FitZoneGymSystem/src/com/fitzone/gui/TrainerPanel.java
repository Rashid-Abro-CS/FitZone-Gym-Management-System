package com.fitzone.gui;

import com.fitzone.model.Trainer;
import com.fitzone.service.TrainerService;
import com.fitzone.util.DateUtils;
import com.fitzone.util.ImageUtils;
import com.fitzone.util.ValidationUtils;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

public class TrainerPanel extends JPanel {

    private TrainerService trainerService;

    // Table components
    private JTable trainerTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JButton searchBtn, refreshBtn, addBtn, editBtn, deleteBtn, clearBtn, viewBtn;

    // Form fields
    private JTextField trainerIdField;
    private JTextField fullNameField;
    private JComboBox<String> genderCombo;
    private JSpinner ageSpinner;
    private JTextField phoneField;
    private JTextField emailField;
    private JTextArea addressArea;
    private JComboBox<String> specializationCombo;
    private JSpinner experienceSpinner;
    private JTextField salaryField;
    private JFormattedTextField joiningDateField;
    private JComboBox<String> statusCombo;
    private JLabel profilePicLabel;
    private JButton uploadPicBtn;

    // For editing
    private Trainer currentEditingTrainer = null;

    public TrainerPanel() {
        trainerService = new TrainerService();

        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(45, 45, 45));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // ---- Top: Title and search ----
        JPanel topPanel = new JPanel(new BorderLayout(10, 5));
        topPanel.setOpaque(false);

        JLabel titleLabel = new JLabel("TRAINER MANAGEMENT", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        topPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setOpaque(false);
        searchPanel.add(new JLabel("Search:"));
        searchField = new JTextField(20);
        searchPanel.add(searchField);
        searchBtn = new JButton("Search");
        searchBtn.setBackground(new Color(70, 130, 180));
        searchBtn.setForeground(Color.WHITE);
        searchBtn.setFocusPainted(false);
        refreshBtn = new JButton("Refresh");
        refreshBtn.setBackground(new Color(100, 100, 100));
        refreshBtn.setForeground(Color.WHITE);
        refreshBtn.setFocusPainted(false);
        searchPanel.add(searchBtn);
        searchPanel.add(refreshBtn);

        topPanel.add(searchPanel, BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        // ---- Center: Table ----
        String[] columns = {"ID", "Name", "Specialization", "Experience", "Phone", "Status", "Salary"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        trainerTable = new JTable(tableModel);
        trainerTable.setRowHeight(25);
        trainerTable.getTableHeader().setBackground(new Color(60, 60, 60));
        trainerTable.getTableHeader().setForeground(Color.WHITE);
        trainerTable.setBackground(new Color(50, 50, 50));
        trainerTable.setForeground(Color.WHITE);
        trainerTable.setSelectionBackground(new Color(200, 50, 50));
        trainerTable.setSelectionForeground(Color.WHITE);
        trainerTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        trainerTable.setFont(new Font("Arial", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(trainerTable);
        scrollPane.getViewport().setBackground(new Color(45, 45, 45));
        add(scrollPane, BorderLayout.CENTER);

        // ---- Bottom: Form and buttons ----
        JPanel bottomPanel = new JPanel(new BorderLayout(10, 10));
        bottomPanel.setOpaque(false);

        // Form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 1),
                "Trainer Details",
                TitledBorder.CENTER,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                Color.WHITE
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Row 0: Trainer ID (auto-generated)
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Trainer ID:"), gbc);
        gbc.gridx = 1;
        trainerIdField = new JTextField(15);
        trainerIdField.setEditable(false);
        trainerIdField.setBackground(new Color(60, 60, 60));
        trainerIdField.setForeground(Color.WHITE);
        formPanel.add(trainerIdField, gbc);

        // Row 1: Full Name
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Full Name:"), gbc);
        gbc.gridx = 1;
        fullNameField = new JTextField(15);
        formPanel.add(fullNameField, gbc);

        // Row 2: Gender and Age
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Gender:"), gbc);
        gbc.gridx = 1;
        genderCombo = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        formPanel.add(genderCombo, gbc);

        gbc.gridx = 2;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Age:"), gbc);
        gbc.gridx = 3;
        ageSpinner = new JSpinner(new SpinnerNumberModel(25, 18, 70, 1));
        formPanel.add(ageSpinner, gbc);

        // Row 3: Phone and Email
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(new JLabel("Phone:"), gbc);
        gbc.gridx = 1;
        phoneField = new JTextField(15);
        formPanel.add(phoneField, gbc);

        gbc.gridx = 2;
        gbc.gridy = 3;
        formPanel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 3;
        emailField = new JTextField(15);
        formPanel.add(emailField, gbc);

        // Row 4: Address
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(new JLabel("Address:"), gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 3;
        addressArea = new JTextArea(2, 20);
        addressArea.setLineWrap(true);
        addressArea.setWrapStyleWord(true);
        JScrollPane addressScroll = new JScrollPane(addressArea);
        addressScroll.setPreferredSize(new Dimension(250, 40));
        formPanel.add(addressScroll, gbc);
        gbc.gridwidth = 1;

        // Row 5: Specialization and Experience
        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(new JLabel("Specialization:"), gbc);
        gbc.gridx = 1;
        specializationCombo = new JComboBox<>(new String[]{
                "Personal Trainer", "Bodybuilding", "Weight Training",
                "Cardio", "CrossFit", "Yoga", "Fitness", "Strength Training"
        });
        formPanel.add(specializationCombo, gbc);

        gbc.gridx = 2;
        gbc.gridy = 5;
        formPanel.add(new JLabel("Experience (years):"), gbc);
        gbc.gridx = 3;
        experienceSpinner = new JSpinner(new SpinnerNumberModel(2, 0, 50, 1));
        formPanel.add(experienceSpinner, gbc);

        // Row 6: Salary and Joining Date
        gbc.gridx = 0;
        gbc.gridy = 6;
        formPanel.add(new JLabel("Salary (Rs.):"), gbc);
        gbc.gridx = 1;
        salaryField = new JTextField(15);
        formPanel.add(salaryField, gbc);

        gbc.gridx = 2;
        gbc.gridy = 6;
        formPanel.add(new JLabel("Joining Date:"), gbc);
        gbc.gridx = 3;
        joiningDateField = new JFormattedTextField(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        joiningDateField.setValue(LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        joiningDateField.setColumns(15);
        formPanel.add(joiningDateField, gbc);

        // Row 7: Status and Profile Picture
        gbc.gridx = 0;
        gbc.gridy = 7;
        formPanel.add(new JLabel("Status:"), gbc);
        gbc.gridx = 1;
        statusCombo = new JComboBox<>(new String[]{"Active", "Inactive"});
        formPanel.add(statusCombo, gbc);

        gbc.gridx = 2;
        gbc.gridy = 7;
        formPanel.add(new JLabel("Profile Picture:"), gbc);
        gbc.gridx = 3;
        JPanel picPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        picPanel.setOpaque(false);
        profilePicLabel = new JLabel();
        profilePicLabel.setIcon(ImageUtils.loadImage("resources/user.png", 40, 40));
        picPanel.add(profilePicLabel);
        uploadPicBtn = new JButton("Upload");
        uploadPicBtn.setBackground(new Color(100, 100, 100));
        uploadPicBtn.setForeground(Color.WHITE);
        uploadPicBtn.setFocusPainted(false);
        picPanel.add(uploadPicBtn);
        formPanel.add(picPanel, gbc);

        // ---- Buttons panel ----
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        buttonPanel.setOpaque(false);

        addBtn = new JButton("Add");
        addBtn.setBackground(new Color(0, 150, 0));
        addBtn.setForeground(Color.WHITE);
        addBtn.setFocusPainted(false);
        addBtn.setIcon(ImageUtils.loadImage("resources/trainer.png", 20, 20));

        editBtn = new JButton("Edit");
        editBtn.setBackground(new Color(200, 160, 0));
        editBtn.setForeground(Color.WHITE);
        editBtn.setFocusPainted(false);

        deleteBtn = new JButton("Delete");
        deleteBtn.setBackground(new Color(200, 50, 50));
        deleteBtn.setForeground(Color.WHITE);
        deleteBtn.setFocusPainted(false);

        clearBtn = new JButton("Clear");
        clearBtn.setBackground(new Color(100, 100, 100));
        clearBtn.setForeground(Color.WHITE);
        clearBtn.setFocusPainted(false);

        viewBtn = new JButton("View");
        viewBtn.setBackground(new Color(70, 130, 180));
        viewBtn.setForeground(Color.WHITE);
        viewBtn.setFocusPainted(false);

        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(clearBtn);
        buttonPanel.add(viewBtn);

        // Add form and buttons to bottom panel
        bottomPanel.add(formPanel, BorderLayout.CENTER);
        bottomPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(bottomPanel, BorderLayout.SOUTH);

        // ---- Load data ----
        loadTrainerData();

        // ---- Event Listeners ----
        addBtn.addActionListener(e -> addTrainer());
        editBtn.addActionListener(e -> editTrainer());
        deleteBtn.addActionListener(e -> deleteTrainer());
        clearBtn.addActionListener(e -> clearForm());
        viewBtn.addActionListener(e -> viewTrainer());
        searchBtn.addActionListener(e -> searchTrainer());
        refreshBtn.addActionListener(e -> {
            loadTrainerData();
            clearForm();
        });

        // Table selection listener to populate form for editing
        trainerTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = trainerTable.getSelectedRow();
                if (row >= 0) {
                    String trainerId = (String) tableModel.getValueAt(row, 0);
                    Trainer trainer = trainerService.getAllTrainers().stream()
                            .filter(t -> t.getId().equals(trainerId))
                            .findFirst().orElse(null);
                    if (trainer != null) {
                        populateForm(trainer);
                    }
                }
            }
        });

        // Upload picture listener
        uploadPicBtn.addActionListener(e -> uploadProfilePicture());
    }

    /**
     * Load all trainers into the table
     */
    private void loadTrainerData() {
        tableModel.setRowCount(0);
        List<Trainer> trainers = trainerService.getAllTrainers();
        for (Trainer t : trainers) {
            tableModel.addRow(new Object[]{
                    t.getId(),
                    t.getFullName(),
                    t.getSpecialization(),
                    t.getExperienceYears(),
                    t.getPhone(),
                    t.getStatus(),
                    t.getSalary()
            });
        }
    }

    /**
     * Search trainers by keyword (ID, Name, Specialization)
     */
    private void searchTrainer() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) {
            loadTrainerData();
            return;
        }
        tableModel.setRowCount(0);
        List<Trainer> filtered = trainerService.searchTrainers(keyword);
        for (Trainer t : filtered) {
            tableModel.addRow(new Object[]{
                    t.getId(),
                    t.getFullName(),
                    t.getSpecialization(),
                    t.getExperienceYears(),
                    t.getPhone(),
                    t.getStatus(),
                    t.getSalary()
            });
        }
    }

    /**
     * Generate next Trainer ID (TR + timestamp)
     */
    private String generateTrainerId() {
        return "TR" + System.currentTimeMillis();
    }

    /**
     * Clear form and reset editing state
     */
    private void clearForm() {
        trainerIdField.setText("");
        fullNameField.setText("");
        genderCombo.setSelectedIndex(0);
        ageSpinner.setValue(25);
        phoneField.setText("");
        emailField.setText("");
        addressArea.setText("");
        specializationCombo.setSelectedIndex(0);
        experienceSpinner.setValue(2);
        salaryField.setText("");
        joiningDateField.setValue(LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        statusCombo.setSelectedIndex(0);
        profilePicLabel.setIcon(ImageUtils.loadImage("resources/user.png", 40, 40));
        currentEditingTrainer = null;
        trainerTable.clearSelection();
        addBtn.setText("Add");
    }

    /**
     * Populate form with data from a Trainer object
     */
    private void populateForm(Trainer trainer) {
        trainerIdField.setText(trainer.getId());
        fullNameField.setText(trainer.getFullName());
        genderCombo.setSelectedItem(trainer.getGender());
        ageSpinner.setValue(trainer.getAge());
        phoneField.setText(trainer.getPhone());
        emailField.setText(trainer.getEmail());
        addressArea.setText(trainer.getAddress());
        specializationCombo.setSelectedItem(trainer.getSpecialization());
        experienceSpinner.setValue(trainer.getExperienceYears());
        salaryField.setText(String.valueOf(trainer.getSalary()));
        joiningDateField.setValue(DateUtils.formatDate(trainer.getJoiningDate()));
        statusCombo.setSelectedItem(trainer.getStatus());
        if (trainer.getProfilePicturePath() != null && !trainer.getProfilePicturePath().isEmpty()) {
            profilePicLabel.setIcon(ImageUtils.loadImage(trainer.getProfilePicturePath(), 40, 40));
        } else {
            profilePicLabel.setIcon(ImageUtils.loadImage("resources/user.png", 40, 40));
        }
        currentEditingTrainer = trainer;
        addBtn.setText("Update");
    }

    /**
     * Validate form fields
     */
    private boolean validateForm() {
        if (fullNameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Full Name is required.");
            fullNameField.requestFocus();
            return false;
        }
        if (phoneField.getText().trim().isEmpty() || !ValidationUtils.isValidPhone(phoneField.getText().trim())) {
            JOptionPane.showMessageDialog(this, "Valid phone number (03XX-XXXXXXX) is required.");
            phoneField.requestFocus();
            return false;
        }
        if (!emailField.getText().trim().isEmpty() && !ValidationUtils.isValidEmail(emailField.getText().trim())) {
            JOptionPane.showMessageDialog(this, "Invalid email format.");
            emailField.requestFocus();
            return false;
        }
        if (!ValidationUtils.isPositiveNumber(salaryField.getText().trim())) {
            JOptionPane.showMessageDialog(this, "Salary must be a positive number.");
            salaryField.requestFocus();
            return false;
        }
        return true;
    }

    /**
     * Add new trainer
     */
    private void addTrainer() {
        if (!validateForm()) return;

        LocalDate joiningDate;
        try {
            joiningDate = DateUtils.parseDate(joiningDateField.getText().trim());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid joining date. Use dd-MM-yyyy.");
            return;
        }

        Trainer trainer = new Trainer();
        trainer.setId(generateTrainerId());
        trainer.setFullName(fullNameField.getText().trim());
        trainer.setGender((String) genderCombo.getSelectedItem());
        trainer.setAge((int) ageSpinner.getValue());
        trainer.setPhone(phoneField.getText().trim());
        trainer.setEmail(emailField.getText().trim());
        trainer.setAddress(addressArea.getText().trim());
        trainer.setSpecialization((String) specializationCombo.getSelectedItem());
        trainer.setExperienceYears((int) experienceSpinner.getValue());
        trainer.setSalary(Double.parseDouble(salaryField.getText().trim()));
        trainer.setJoiningDate(joiningDate);
        trainer.setStatus((String) statusCombo.getSelectedItem());
        // Profile picture path would be set if uploaded

        trainerService.addTrainer(trainer);
        JOptionPane.showMessageDialog(this, "Trainer added successfully.");
        loadTrainerData();
        clearForm();
    }

    /**
     * Edit existing trainer
     */
    private void editTrainer() {
        if (currentEditingTrainer == null) {
            JOptionPane.showMessageDialog(this, "Please select a trainer from the table to edit.");
            return;
        }
        if (!validateForm()) return;

        LocalDate joiningDate;
        try {
            joiningDate = DateUtils.parseDate(joiningDateField.getText().trim());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid joining date. Use dd-MM-yyyy.");
            return;
        }

        currentEditingTrainer.setFullName(fullNameField.getText().trim());
        currentEditingTrainer.setGender((String) genderCombo.getSelectedItem());
        currentEditingTrainer.setAge((int) ageSpinner.getValue());
        currentEditingTrainer.setPhone(phoneField.getText().trim());
        currentEditingTrainer.setEmail(emailField.getText().trim());
        currentEditingTrainer.setAddress(addressArea.getText().trim());
        currentEditingTrainer.setSpecialization((String) specializationCombo.getSelectedItem());
        currentEditingTrainer.setExperienceYears((int) experienceSpinner.getValue());
        currentEditingTrainer.setSalary(Double.parseDouble(salaryField.getText().trim()));
        currentEditingTrainer.setJoiningDate(joiningDate);
        currentEditingTrainer.setStatus((String) statusCombo.getSelectedItem());

        trainerService.updateTrainer(currentEditingTrainer);
        JOptionPane.showMessageDialog(this, "Trainer updated successfully.");
        loadTrainerData();
        clearForm();
    }

    /**
     * Delete selected trainer
     */
    private void deleteTrainer() {
        int row = trainerTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a trainer to delete.");
            return;
        }
        String trainerId = (String) tableModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete trainer " + trainerId + "?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            trainerService.deleteTrainer(trainerId);
            JOptionPane.showMessageDialog(this, "Trainer deleted.");
            loadTrainerData();
            clearForm();
        }
    }

    /**
     * View trainer details in a profile dialog
     */
    private void viewTrainer() {
        int row = trainerTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a trainer to view.");
            return;
        }
        String trainerId = (String) tableModel.getValueAt(row, 0);
        Trainer trainer = trainerService.getAllTrainers().stream()
                .filter(t -> t.getId().equals(trainerId))
                .findFirst().orElse(null);
        if (trainer == null) return;

        // Build profile display
        StringBuilder sb = new StringBuilder();
        sb.append("=====================================\n");
        sb.append("           FITZONE\n");
        sb.append("        TRAINER PROFILE\n");
        sb.append("=====================================\n\n");
        sb.append("ID: ").append(trainer.getId()).append("\n");
        sb.append("Name: ").append(trainer.getFullName()).append("\n");
        sb.append("Gender: ").append(trainer.getGender()).append("\n");
        sb.append("Age: ").append(trainer.getAge()).append("\n");
        sb.append("Phone: ").append(trainer.getPhone()).append("\n");
        sb.append("Email: ").append(trainer.getEmail()).append("\n");
        sb.append("Address: ").append(trainer.getAddress()).append("\n");
        sb.append("Specialization: ").append(trainer.getSpecialization()).append("\n");
        sb.append("Experience: ").append(trainer.getExperienceYears()).append(" years\n");
        sb.append("Salary: Rs. ").append(trainer.getSalary()).append("\n");
        sb.append("Joining Date: ").append(DateUtils.formatDate(trainer.getJoiningDate())).append("\n");
        sb.append("Status: ").append(trainer.getStatus()).append("\n");

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 13));
        JScrollPane scroll = new JScrollPane(textArea);
        scroll.setPreferredSize(new Dimension(400, 450));
        JOptionPane.showMessageDialog(this, scroll, "Trainer Profile", JOptionPane.PLAIN_MESSAGE);
    }

    /**
     * Upload profile picture
     */
    private void uploadProfilePicture() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Images", "jpg", "jpeg", "png", "gif"));
        int choice = chooser.showOpenDialog(this);
        if (choice == JFileChooser.APPROVE_OPTION) {
            String path = chooser.getSelectedFile().getAbsolutePath();
            profilePicLabel.setIcon(ImageUtils.loadImage(path, 40, 40));
            // If editing an existing trainer, update the path
            if (currentEditingTrainer != null) {
                currentEditingTrainer.setProfilePicturePath(path);
            }
        }
    }
}