package com.fitzone.model;

import java.io.Serializable;

/**
 * Holds gym configuration and admin account settings.
 */
public class GymSettings implements Serializable {
    private static final long serialVersionUID = 1L;

    private String gymName;
    private String gymAddress;
    private String gymPhone;
    private String gymEmail;
    private String adminName;
    private String adminUsername;
    private String adminPassword; // stored as hashed value
    private String theme;

    public GymSettings() {
        // Defaults
        this.gymName = "FitZone Gym";
        this.gymAddress = "123 Fitness Street, City";
        this.gymPhone = "03XX-XXXXXXX";
        this.gymEmail = "info@fitzone.com";
        this.adminName = "Admin";
        this.adminUsername = "admin";
        this.adminPassword = null;
        this.theme = "Dark Gym Theme";
    }

    public GymSettings(String gymName, String gymAddress, String gymPhone, String gymEmail,
                        String adminName, String adminUsername, String adminPassword, String theme) {
        this.gymName = gymName;
        this.gymAddress = gymAddress;
        this.gymPhone = gymPhone;
        this.gymEmail = gymEmail;
        this.adminName = adminName;
        this.adminUsername = adminUsername;
        this.adminPassword = adminPassword;
        this.theme = theme;
    }

    // Getters and Setters
    public String getGymName() { return gymName; }
    public void setGymName(String gymName) { this.gymName = gymName; }

    public String getGymAddress() { return gymAddress; }
    public void setGymAddress(String gymAddress) { this.gymAddress = gymAddress; }

    public String getGymPhone() { return gymPhone; }
    public void setGymPhone(String gymPhone) { this.gymPhone = gymPhone; }

    public String getGymEmail() { return gymEmail; }
    public void setGymEmail(String gymEmail) { this.gymEmail = gymEmail; }

    public String getAdminName() { return adminName; }
    public void setAdminName(String adminName) { this.adminName = adminName; }

    public String getAdminUsername() { return adminUsername; }
    public void setAdminUsername(String adminUsername) { this.adminUsername = adminUsername; }

    public String getAdminPassword() { return adminPassword; }
    public void setAdminPassword(String adminPassword) { this.adminPassword = adminPassword; }

    public String getTheme() { return theme; }
    public void setTheme(String theme) { this.theme = theme; }

    @Override
    public String toString() {
        return gymName + " (" + adminUsername + ")";
    }
}
