package com.fitzone;

import com.fitzone.gui.SplashScreen;

public class Main {
    public static void main(String[] args) {
        // Launch splash screen
        java.awt.EventQueue.invokeLater(() -> {
            new SplashScreen().setVisible(true);
        });
    }
}